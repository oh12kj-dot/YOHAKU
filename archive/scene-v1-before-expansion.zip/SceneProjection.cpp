#include "SceneProjection.h"
#include "FurnitureDefinition.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "Materials/MaterialInterface.h"

AYFurnitureActor::AYFurnitureActor()
{
    RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    PickBounds = CreateDefaultSubobject<UBoxComponent>(TEXT("PickBounds"));
    PickBounds->SetupAttachment(RootComponent);
    PickBounds->SetBoxExtent(FVector(75, 43.5, 41));
    PickBounds->SetRelativeLocation(FVector(0, 0, 41));
    PickBounds->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    PickBounds->SetCollisionResponseToAllChannels(ECR_Ignore);
    PickBounds->SetCollisionResponseToChannel(ECC_Visibility, ECR_Block);
}
void AYFurnitureActor::Build(UFurnitureDefinition *D)
{
    for (auto P : Parts)
        P->DestroyComponent();
    Parts.Reset();
    if (!D)
        return;
    for (const auto &Part : D->Parts)
    {
        auto *C = NewObject<UStaticMeshComponent>(this);
        C->SetupAttachment(RootComponent);
        C->SetStaticMesh(Part.Mesh);
        C->SetMaterial(0, Part.Material);
        C->SetRelativeTransform(Part.Transform);
        C->SetMobility(EComponentMobility::Movable);
        C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
        C->RegisterComponent();
        Parts.Add(C);
    }
}
void AYFurnitureActor::SetPose(const Yohaku::FItem &I)
{
    InstanceId = I.Id;
    Variant = I.Variant;
    SetActorLocationAndRotation(FVector(I.X / 10, I.Z / 10, 0), FRotator(0, -FMath::RadiansToDegrees(I.Yaw), 0));
    SetActorScale3D(FVector::OneVector);
}
void AYFurnitureActor::SetSelected(bool S)
{
    for (auto P : Parts)
    {
        P->SetRenderCustomDepth(S);
        P->SetCustomDepthStencilValue(S ? 1 : 0);
    }
}
AYSceneProjection::AYSceneProjection()
{
    RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    for (int32 I = 0; I < 5; ++I)
    {
        auto *C = CreateDefaultSubobject<UStaticMeshComponent>(*FString::Printf(TEXT("Surface%d"), I));
        C->SetupAttachment(RootComponent);
        C->SetCollisionEnabled(ECollisionEnabled::NoCollision);
        C->SetMobility(EComponentMobility::Movable);
        Surfaces.Add(C);
    }
}
void AYSceneProjection::SetSurface(int32 I, const FVector &P, const FVector &Size, int32 Finish)
{
    auto *C = Surfaces[I].Get();
    if (!C->GetStaticMesh())
        C->SetStaticMesh(LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube")));
    C->SetRelativeLocation(P);
    C->SetRelativeScale3D(Size / 100);
    const TCHAR *Floors[] = {TEXT("Oak"), TEXT("Walnut"), TEXT("WhiteOak"), TEXT("Stone")};
    const TCHAR *Walls[] = {TEXT("Ivory"), TEXT("Sage"), TEXT("Clay"), TEXT("Chalk"), TEXT("Slate")};
    const FString Mat = FString::Printf(TEXT("/Game/Finishes/M_%s.M_%s"), I == 0 ? Floors[Finish] : Walls[Finish],
                                        I == 0 ? Floors[Finish] : Walls[Finish]);
    C->SetMaterial(0, LoadObject<UMaterialInterface>(nullptr, *Mat));
}
void AYSceneProjection::Reconcile(const Yohaku::FScene &S, const FGuid &Selected)
{
    if (!Brown)
        Brown = LoadObject<UFurnitureDefinition>(nullptr, TEXT("/Game/Catalog/PSFBrown.PSFBrown"));
    if (!BlueGray)
        BlueGray = LoadObject<UFurnitureDefinition>(nullptr, TEXT("/Game/Catalog/PSFBlueGray.PSFBlueGray"));
    const double W = S.Width / 10, D = S.Depth / 10, H = S.Height / 10;
    RoomWidth = W;
    RoomDepth = D;
    SetSurface(0, FVector(W / 2, D / 2, -3), FVector(W, D, 6), S.Finishes[0]);
    SetSurface(1, FVector(W / 2, D + 5, H / 2), FVector(W + 20, 10, H), S.Finishes[1]);
    SetSurface(2, FVector(W / 2, -5, H / 2), FVector(W + 20, 10, H), S.Finishes[2]);
    SetSurface(3, FVector(W + 5, D / 2, H / 2), FVector(10, D, H), S.Finishes[3]);
    SetSurface(4, FVector(-5, D / 2, H / 2), FVector(10, D, H), S.Finishes[4]);
    TSet<FGuid> Keep;
    for (const auto &I : S.Items)
    {
        Keep.Add(I.Id);
        AYFurnitureActor *Actor = Find(I.Id);
        if (!Actor)
        {
            Actor = GetWorld()->SpawnActor<AYFurnitureActor>();
            Furniture.Add(I.Id, Actor);
            Actor->Build(I.Variant == Yohaku::EVariant::Brown ? Brown : BlueGray);
        }
        else if (Actor->Variant != I.Variant)
            Actor->Build(I.Variant == Yohaku::EVariant::Brown ? Brown : BlueGray);
        Actor->SetPose(I);
        Actor->SetSelected(I.Id == Selected);
    }
    TArray<FGuid> Remove;
    for (const auto &Pair : Furniture)
        if (!Keep.Contains(Pair.Key))
        {
            Pair.Value->Destroy();
            Remove.Add(Pair.Key);
        }
    for (auto Id : Remove)
        Furniture.Remove(Id);
}
AYFurnitureActor *AYSceneProjection::Find(const FGuid &Id) const
{
    const auto *A = Furniture.Find(Id);
    return A ? A->Get() : nullptr;
}
void AYSceneProjection::PreviewPose(const Yohaku::FItem &I)
{
    if (auto *A = Find(I.Id))
        A->SetPose(I);
}
void AYSceneProjection::ShowGhost(const Yohaku::FItem &I)
{
    if (!Ghost)
    {
        Ghost = GetWorld()->SpawnActor<AYFurnitureActor>();
        Ghost->Build(I.Variant == Yohaku::EVariant::Brown ? Brown : BlueGray);
        Ghost->PickBounds->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }
    else if (Ghost->Variant != I.Variant)
        Ghost->Build(I.Variant == Yohaku::EVariant::Brown ? Brown : BlueGray);
    auto *Preview = LoadObject<UMaterialInterface>(nullptr, TEXT("/Game/Finishes/M_Preview.M_Preview"));
    for (auto P : Ghost->Parts)
        P->SetMaterial(0, Preview);
    Ghost->SetPose(I);
    Ghost->SetActorHiddenInGame(false);
    Ghost->SetSelected(true);
}
void AYSceneProjection::HideGhost()
{
    if (Ghost)
        Ghost->SetActorHiddenInGame(true);
}
void AYSceneProjection::Cutaway(const FVector &C)
{
    Surfaces[1]->SetVisibility(C.Y <= RoomDepth);
    Surfaces[2]->SetVisibility(C.Y >= 0);
    Surfaces[3]->SetVisibility(C.X <= RoomWidth);
    Surfaces[4]->SetVisibility(C.X >= 0);
}
