#pragma once
#include "CoreMinimal.h"

namespace Yohaku
{
enum class ESurface : uint8
{
    Floor,
    North,
    South,
    East,
    West
};
enum class EVariant : uint8
{
    Brown,
    BlueGray
};

struct FItem
{
    FGuid Id = FGuid::NewGuid();
    EVariant Variant = EVariant::Brown;
    double X = 2000, Z = 2000, Yaw = 0;
    bool operator==(const FItem &B) const
    {
        return Id == B.Id && Variant == B.Variant && X == B.X && Z == B.Z && Yaw == B.Yaw;
    }
};

struct FScene
{
    double Width = 5000, Depth = 4000, Height = 2600;
    TArray<int32> Finishes = {0, 0, 0, 0, 0};
    TArray<FItem> Items;
    bool operator==(const FScene &B) const
    {
        return Width == B.Width && Depth == B.Depth && Height == B.Height && Finishes == B.Finishes && Items == B.Items;
    }
};
enum class EEditType : uint8
{
    Room,
    Surface,
    Add,
    Move,
    Remove,
    Duplicate,
    Variant
};
struct FEdit
{
    EEditType Type = EEditType::Room;
    FItem Item;
    FGuid Target;
    double Width = 5000, Depth = 4000, Height = 2600;
    ESurface Surface = ESurface::Floor;
    int32 Finish = 0;
};
struct FWarning
{
    FGuid First, Second;
    FString Message;
};
YOHAKUCORE_API bool Validate(const FScene &Scene, FString &Error);
YOHAKUCORE_API bool Apply(const FScene &Before, const FEdit &Edit, FScene &After, FString &Error);
YOHAKUCORE_API TArray<FWarning> Warnings(const FScene &Scene);
YOHAKUCORE_API FString Encode(const FScene &Scene);
YOHAKUCORE_API bool Decode(const FString &Json, FScene &Out, FString &Error);
YOHAKUCORE_API FString VariantId(EVariant Variant);
YOHAKUCORE_API double Normalize(double Value);
class YOHAKUCORE_API FDocument
{
  public:
    const FScene &Get() const { return Scene; }
    bool Commit(const FEdit &Edit, FString &Error);
    bool Undo();
    bool Redo();
    bool CanUndo() const { return Past.Num() > 0; }
    bool CanRedo() const { return Future.Num() > 0; }
    int32 UndoCount() const { return Past.Num(); }
    bool Dirty() const { return Encode(Scene) != SavedJson; }
    void MarkSaved() { SavedJson = Encode(Scene); }
    bool ReplaceLoaded(const FString &Json, FString &Error);

  private:
    FScene Scene;
    TArray<FScene> Past, Future;
    FString SavedJson;
};
} // namespace Yohaku
