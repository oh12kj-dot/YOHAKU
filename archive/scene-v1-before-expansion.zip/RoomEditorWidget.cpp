#include "RoomEditorWidget.h"
#include "RoomController.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SSeparator.h"
#include "Widgets/Layout/SUniformGridPanel.h"
#include "Widgets/SOverlay.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SSpinBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Styling/CoreStyle.h"
#include "Brushes/SlateColorBrush.h"
#include "ProductResearchWidget.h"
#include "RoomEditorStyle.h"

namespace
{
const FLinearColor Ink(.10f, .15f, .14f), Muted(.34f, .40f, .34f), Paper(.93f, .94f, .88f, .97f),
    Accent(.43f, .57f, .35f);
TSharedRef<STextBlock> Text(const FString &Label, int32 Size = 13, FLinearColor Color = Ink)
{
    return SNew(STextBlock)
        .Text(FText::FromString(Label))
        .Font(FCoreStyle::GetDefaultFontStyle("Regular", Size))
        .ColorAndOpacity(Color);
}
using YohakuUI::EditorButtonStyle;
TSharedRef<SButton> Button(const FString &Label, TFunction<void()> Action)
{
    return SNew(SButton)
        .ButtonStyle(&EditorButtonStyle())
        .IsFocusable(false)
        .ContentPadding(FMargin(12, 8))
        .OnClicked_Lambda([Action]() {
            Action();
            return FReply::Handled();
        })[Text(Label)];
}
TSharedRef<SWidget> Section(const FString &Title)
{
    return SNew(SBox).Padding(FMargin(0, 14, 0, 7))[Text(Title, 15)];
}
} // namespace
void SRoomEditor::Construct(const FArguments &Args)
{
    SetVisibility(EVisibility::SelfHitTestInvisible);
    Controller = Args._Controller;
    const auto C = Controller;
    auto Left = SNew(SVerticalBox);
    Left->AddSlot().AutoHeight()[Text(TEXT("ROOM / 部屋づくり"), 12, Muted)];
    Left->AddSlot().AutoHeight().Padding(0, 9)[Button(TEXT("平面で部屋を描く"), [C]() {
        if (C.IsValid())
            C->SetTool(ERoomTool::DrawRoom);
    })];
    for (int32 Axis = 0; Axis < 3; ++Axis)
    {
        const FString Label = Axis == 0 ? TEXT("幅") : Axis == 1 ? TEXT("奥行") : TEXT("天井高");
        Left->AddSlot().AutoHeight().Padding(
            0, 3)[SNew(SHorizontalBox) + SHorizontalBox::Slot().FillWidth(1).VAlign(VAlign_Center)[Text(Label)] +
                  SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(
                      125)[SNew(SSpinBox<double>)
                               .MinValue(Axis == 2 ? 1000.0 : 500.0)
                               .MaxValue(Axis == 2 ? 6000.0 : 30000.0)
                               .Delta(100)
                               .MinFractionalDigits(0)
                               .MaxFractionalDigits(1)
                               .Value_Lambda([C, Axis]() {
                                   if (!C.IsValid())
                                       return 0.0;
                                   const auto &S = C->Document.Get();
                                   return Axis == 0 ? S.Width : Axis == 1 ? S.Depth : S.Height;
                               })
                               .OnValueCommitted_Lambda([C, Axis](double V, ETextCommit::Type) {
                                   if (C.IsValid())
                                   {
                                       const auto S = C->Document.Get();
                                       C->SetRoom(Axis == 0 ? V : S.Width, Axis == 1 ? V : S.Depth,
                                                  Axis == 2 ? V : S.Height);
                                   }
                               })]] +
                  SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(5, 0)[Text(TEXT("mm"), 11, Muted)]];
    }
    Left->AddSlot().AutoHeight().Padding(0, 5)[Text(TEXT("寸法は入力値・実測照合は未実施"), 10, Muted)];
    Left->AddSlot().AutoHeight()[Section(TEXT("SURFACE / 壁・床"))];
    auto Targets = SNew(SUniformGridPanel).SlotPadding(FMargin(2));
    const TCHAR *TargetNames[] = {TEXT("床"), TEXT("北壁"), TEXT("南壁"), TEXT("東壁"), TEXT("西壁")};
    for (int32 I = 0; I < 5; ++I)
        Targets->AddSlot(I % 3, I / 3)[Button(TargetNames[I], [C, I]() {
            if (C.IsValid())
                C->Surface = static_cast<Yohaku::ESurface>(I);
        })];
    Left->AddSlot().AutoHeight()[Targets];
    Left->AddSlot().AutoHeight().Padding(0, 5)[SNew(STextBlock).ColorAndOpacity(Muted).Text_Lambda([C]() {
        const TCHAR *Names[] = {TEXT("床"), TEXT("北壁"), TEXT("南壁"), TEXT("東壁"), TEXT("西壁")};
        return FText::FromString(C.IsValid() ? FString::Printf(TEXT("対象：%s"), Names[static_cast<int32>(C->Surface)])
                                             : TEXT(""));
    })];
    const TCHAR *FloorNames[] = {TEXT("オーク"), TEXT("ウォルナット"), TEXT("白木"), TEXT("石")};
    const TCHAR *WallNames[] = {TEXT("アイボリー"), TEXT("セージ"), TEXT("クレイ"), TEXT("白"), TEXT("スレート")};
    for (int32 I = 0; I < 5; ++I)
        Left->AddSlot().AutoHeight().Padding(0, 2)[SNew(SBox).Visibility_Lambda([C, I]() {
            return C.IsValid() && C->Surface == Yohaku::ESurface::Floor && I == 4 ? EVisibility::Collapsed
                                                                                  : EVisibility::Visible;
        })[SNew(SButton)
               .ButtonStyle(&EditorButtonStyle())
               .IsFocusable(false)
               .ContentPadding(FMargin(9, 5))
               .OnClicked_Lambda([C, I]() {
                   if (C.IsValid())
                       C->SetFinish(I);
                   return FReply::Handled();
               })[SNew(STextBlock).ColorAndOpacity(Ink).Text_Lambda([C, I, FloorNames, WallNames]() {
                   return FText::FromString(C.IsValid() && C->Surface == Yohaku::ESurface::Floor ? FloorNames[I % 4]
                                                                                                 : WallNames[I]);
               })]]];
    Left->AddSlot().AutoHeight()[Section(TEXT("FURNITURE / 家具"))];
    Left->AddSlot().AutoHeight()[Text(TEXT("PSF SOFA 2P — 検証用候補"), 12)];
    Left->AddSlot().AutoHeight().Padding(0, 5)[Text(TEXT("W1500 × D870 × H820 mm"), 11, Muted)];
    Left->AddSlot().AutoHeight().Padding(0, 2)[Button(TEXT("ブラウンを配置"), [C]() {
        if (C.IsValid())
            C->StartPlacement(Yohaku::EVariant::Brown);
    })];
    Left->AddSlot().AutoHeight().Padding(0, 2)[Button(TEXT("ブルーグレーを配置"), [C]() {
        if (C.IsValid())
            C->StartPlacement(Yohaku::EVariant::BlueGray);
    })];
    Left->AddSlot().AutoHeight().Padding(0, 8)[Text(TEXT("写真参照の試作 / 実物校正・正式採用前"), 10, Muted)];
    auto Right = SNew(SVerticalBox);
    Right->AddSlot().AutoHeight()[Text(TEXT("INSPECTOR / 選択した家具"), 12, Muted)];
    Right->AddSlot().AutoHeight().Padding(
        0, 10)[SNew(STextBlock).ColorAndOpacity(Ink).AutoWrapText(true).Text_Lambda([C]() {
        return FText::FromString(C.IsValid() && C->SelectedItem() ? TEXT("PSF SOFA 2P\n固定外寸：1500 × 870 × 820 mm")
                                                                  : TEXT("家具をクリックして選択"));
    })];
    for (int32 Axis = 0; Axis < 3; ++Axis)
    {
        Right->AddSlot().AutoHeight().Padding(
            0, 4)[SNew(SHorizontalBox) +
                  SHorizontalBox::Slot().FillWidth(1).VAlign(VAlign_Center)[Text(Axis == 0   ? TEXT("X mm")
                                                                                 : Axis == 1 ? TEXT("Z mm")
                                                                                             : TEXT("角度 °"))] +
                  SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(
                      125)[SNew(SSpinBox<double>)
                               .IsEnabled_Lambda([C]() { return C.IsValid() && C->SelectedItem(); })
                               .MinValue(-100000)
                               .MaxValue(100000)
                               .Delta(Axis == 2 ? 45 : 100)
                               .MaxFractionalDigits(1)
                               .Value_Lambda([C, Axis]() {
                                   const auto *I = C.IsValid() ? C->SelectedItem() : nullptr;
                                   return I ? (Axis == 0   ? I->X
                                               : Axis == 1 ? I->Z
                                                           : FMath::RadiansToDegrees(I->Yaw))
                                            : 0.0;
                               })
                               .OnValueCommitted_Lambda([C, Axis](double V, ETextCommit::Type) {
                                   if (C.IsValid())
                                       if (const auto *I = C->SelectedItem())
                                       {
                                           const auto Item = *I;
                                           C->EditPose(Axis == 0 ? V : Item.X, Axis == 1 ? V : Item.Z,
                                                       Axis == 2 ? V : FMath::RadiansToDegrees(Item.Yaw));
                                       }
                               })]]];
    }
    Right->AddSlot().AutoHeight().Padding(0, 8)[Button(TEXT("45° 回転  [R]"), [C]() {
        if (C.IsValid())
            C->Rotate();
    })];
    Right->AddSlot().AutoHeight().Padding(0, 2)[Button(TEXT("ブラウンへ交換"), [C]() {
        if (C.IsValid())
            C->ChangeVariant(Yohaku::EVariant::Brown);
    })];
    Right->AddSlot().AutoHeight().Padding(0, 2)[Button(TEXT("ブルーグレーへ交換"), [C]() {
        if (C.IsValid())
            C->ChangeVariant(Yohaku::EVariant::BlueGray);
    })];
    Right->AddSlot().AutoHeight().Padding(
        0, 9)[SNew(SHorizontalBox) + SHorizontalBox::Slot().FillWidth(1)[Button(TEXT("複製"), [C]() {
        if (C.IsValid())
            C->Duplicate();
    })] + SHorizontalBox::Slot().FillWidth(1)[Button(TEXT("削除"), [C]() {
        if (C.IsValid())
            C->DeleteSelected();
    })]];
    Right->AddSlot().AutoHeight()[Section(TEXT("VIEW / 視点"))];
    const TCHAR *Views[] = {TEXT("俯瞰"), TEXT("真上"), TEXT("室内")};
    for (int32 I = 0; I < 3; ++I)
        Right->AddSlot().AutoHeight().Padding(0, 2)[Button(Views[I], [C, I]() {
            if (C.IsValid())
                C->View(I);
        })];
    Right->AddSlot().AutoHeight().Padding(0, 12)[SNew(SCheckBox)
                                                     .IsChecked_Lambda([C]() {
                                                         return C.IsValid() && C->bSnap ? ECheckBoxState::Checked
                                                                                        : ECheckBoxState::Unchecked;
                                                     })
                                                     .OnCheckStateChanged_Lambda([C](ECheckBoxState S) {
                                                         if (C.IsValid())
                                                             C->bSnap = S == ECheckBoxState::Checked;
                                                     })[Text(TEXT("100 mm スナップ"), 12)]];
    Right->AddSlot().AutoHeight().Padding(0, 8)[Text(TEXT("左ドラッグ：家具の移動\n右ドラッグ：視点回転\nShift＋右：視"
                                                          "点移動\nホイール：拡大・縮小\nEsc：未確定の操作を中止"),
                                                     11, Muted)];
    ChildSlot[SNew(SOverlay) +
              SOverlay::Slot().VAlign(VAlign_Top)
                  [SNew(SBorder)
                       .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                       .BorderBackgroundColor(Paper)
                       .Padding(FMargin(24, 14))
                           [SNew(SHorizontalBox) +
                            SHorizontalBox::Slot().FillWidth(1).VAlign(VAlign_Center)
                                [SNew(SHorizontalBox) + SHorizontalBox::Slot().AutoWidth()[Text(TEXT("余白"), 27)] +
                                 SHorizontalBox::Slot().AutoWidth().Padding(
                                     18, 10)[Text(TEXT("Y O H A K U   /   ROOM STUDIO"), 11, Muted)]] +
                            SHorizontalBox::Slot().AutoWidth().Padding(3, 0)[Button(TEXT("商品URL"),
                                                                                    [C]() {
                                                                                        if (C.IsValid())
                                                                                            C->bShowResearch =
                                                                                                !C->bShowResearch;
                                                                                    })] +
                            SHorizontalBox::Slot().AutoWidth().Padding(3, 0)[Button(TEXT("選択"),
                                                                                    [C]() {
                                                                                        if (C.IsValid())
                                                                                            C->SetTool(
                                                                                                ERoomTool::Select);
                                                                                    })] +
                            SHorizontalBox::Slot().AutoWidth().Padding(3, 0)[Button(TEXT("元に戻す"),
                                                                                    [C]() {
                                                                                        if (C.IsValid())
                                                                                            C->Undo();
                                                                                    })] +
                            SHorizontalBox::Slot().AutoWidth().Padding(3, 0)[Button(TEXT("やり直す"),
                                                                                    [C]() {
                                                                                        if (C.IsValid())
                                                                                            C->Redo();
                                                                                    })] +
                            SHorizontalBox::Slot().AutoWidth().Padding(3, 0)[Button(TEXT("保存"),
                                                                                    [C]() {
                                                                                        if (C.IsValid())
                                                                                            C->Save();
                                                                                    })] +
                            SHorizontalBox::Slot().AutoWidth().Padding(3, 0)[Button(TEXT("読込"),
                                                                                    [C]() {
                                                                                        if (C.IsValid())
                                                                                            C->Load();
                                                                                    })]]] +
              SOverlay::Slot()
                  .HAlign(HAlign_Left)
                  .VAlign(VAlign_Fill)
                  .Padding(FMargin(18, 86, 0, 78))[SNew(SBox).WidthOverride(
                      262)[SNew(SBorder)
                               .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                               .BorderBackgroundColor(Paper)
                               .Padding(15)[SNew(SScrollBox) + SScrollBox::Slot()[Left]]]] +
              SOverlay::Slot()
                  .HAlign(HAlign_Right)
                  .VAlign(VAlign_Fill)
                  .Padding(FMargin(0, 86, 18, 78))[SNew(SBox).WidthOverride(
                      252)[SNew(SBorder)
                               .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                               .BorderBackgroundColor(Paper)
                               .Padding(15)[SNew(SScrollBox) + SScrollBox::Slot()[Right]]]] +
              SOverlay::Slot()
                  .HAlign(HAlign_Center)
                  .VAlign(VAlign_Bottom)
                  .Padding(0, 0, 0, 16)[SNew(SBox).MinDesiredWidth(
                      580)[SNew(SBorder)
                               .BorderImage(FCoreStyle::Get().GetBrush("WhiteBrush"))
                               .BorderBackgroundColor(Paper)
                               .Padding(FMargin(18, 10))[SNew(STextBlock).ColorAndOpacity(Ink).Text_Lambda([C]() {
                                   return FText::FromString(C.IsValid() ? C->Status() : TEXT(""));
                               })]]] +
              SOverlay::Slot()
                  .HAlign(HAlign_Center)
                  .VAlign(VAlign_Center)[SNew(SBox).WidthOverride(660).HeightOverride(600).Visibility_Lambda([C]() {
                      return C.IsValid() && C->bShowResearch ? EVisibility::Visible : EVisibility::Collapsed;
                  })[SNew(SProductResearch).Research(C->Research).OnClose_Lambda([C]() {
                      if (C.IsValid())
                          C->bShowResearch = false;
                  })]]];
}
