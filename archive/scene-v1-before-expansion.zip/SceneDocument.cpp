#include "SceneDocument.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"

namespace Yohaku
{
double Normalize(double V)
{
    return FMath::RoundToDouble(V * 1000.0) / 1000.0;
}
FString VariantId(EVariant V)
{
    return V == EVariant::Brown ? TEXT("study-psf-v3-brown") : TEXT("study-psf-v3-blue-gray");
}
static double Angle(double V)
{
    double A = FMath::Fmod(V, UE_DOUBLE_TWO_PI);
    if (A > UE_DOUBLE_PI)
        A -= UE_DOUBLE_TWO_PI;
    if (A < -UE_DOUBLE_PI)
        A += UE_DOUBLE_TWO_PI;
    return A;
}
static bool FiniteRange(double V, double Low, double High)
{
    return FMath::IsFinite(V) && V >= Low && V <= High;
}
bool Validate(const FScene &S, FString &Error)
{
    if (!FiniteRange(S.Width, 500, 30000) || !FiniteRange(S.Depth, 500, 30000) || !FiniteRange(S.Height, 1000, 6000))
    {
        Error = TEXT("部屋寸法の範囲外です（幅・奥行500〜30000mm、高さ1000〜6000mm）");
        return false;
    }
    if (S.Finishes.Num() != 5)
    {
        Error = TEXT("床と4壁の仕上げが必要です");
        return false;
    }
    for (int32 I = 0; I < 5; ++I)
        if (S.Finishes[I] < 0 || S.Finishes[I] > (I == 0 ? 3 : 4))
        {
            Error = TEXT("未知の仕上げです");
            return false;
        }
    if (S.Items.Num() > 200)
    {
        Error = TEXT("試作版の配置上限200点です");
        return false;
    }
    TSet<FGuid> Ids;
    for (const FItem &Item : S.Items)
    {
        if (!Item.Id.IsValid() || Ids.Contains(Item.Id) || !FiniteRange(Item.X, -100000, 100000) ||
            !FiniteRange(Item.Z, -100000, 100000) || !FMath::IsFinite(Item.Yaw) ||
            (Item.Variant != EVariant::Brown && Item.Variant != EVariant::BlueGray))
        {
            Error = TEXT("家具ID・位置・仕様が不正です");
            return false;
        }
        Ids.Add(Item.Id);
    }
    return true;
}
bool Apply(const FScene &Before, const FEdit &E, FScene &After, FString &Error)
{
    After = Before;
    const int32 At = After.Items.IndexOfByPredicate([&](const FItem &I) { return I.Id == E.Target; });
    switch (E.Type)
    {
    case EEditType::Room:
        After.Width = Normalize(E.Width);
        After.Depth = Normalize(E.Depth);
        After.Height = Normalize(E.Height);
        break;
    case EEditType::Surface:
        if (static_cast<uint8>(E.Surface) > 4)
        {
            Error = TEXT("未知の面です");
            return false;
        }
        After.Finishes[static_cast<int32>(E.Surface)] = E.Finish;
        break;
    case EEditType::Add:
        After.Items.Add(E.Item);
        break;
    case EEditType::Move:
        if (At == INDEX_NONE)
        {
            Error = TEXT("家具が見つかりません");
            return false;
        }
        After.Items[At].X = E.Item.X;
        After.Items[At].Z = E.Item.Z;
        After.Items[At].Yaw = E.Item.Yaw;
        break;
    case EEditType::Remove:
        if (At == INDEX_NONE)
            return false;
        After.Items.RemoveAt(At);
        break;
    case EEditType::Duplicate:
        if (At == INDEX_NONE)
            return false;
        {
            FItem Copy = After.Items[At];
            Copy.Id = E.Item.Id;
            Copy.X = E.Item.X;
            Copy.Z = E.Item.Z;
            After.Items.Add(Copy);
        }
        break;
    case EEditType::Variant:
        if (At == INDEX_NONE)
            return false;
        After.Items[At].Variant = E.Item.Variant;
        break;
    default:
        Error = TEXT("未知の編集コマンドです");
        return false;
    }
    if (!Validate(After, Error))
        return false;
    for (FItem &I : After.Items)
    {
        I.X = Normalize(I.X);
        I.Z = Normalize(I.Z);
        I.Yaw = Angle(I.Yaw);
    }
    return Validate(After, Error);
}

static TArray<FVector2D> Corners(const FItem &I)
{
    TArray<FVector2D> R;
    const double C = FMath::Cos(I.Yaw), S = FMath::Sin(I.Yaw);
    for (double X : {-750.0, 750.0})
        for (double Z : {-435.0, 435.0})
            R.Add(FVector2D(I.X + C * X + S * Z, I.Z - S * X + C * Z));
    return R;
}
static bool Overlap(const FItem &A, const FItem &B)
{
    const auto CA = Corners(A), CB = Corners(B);
    for (double Yaw : {A.Yaw, B.Yaw})
        for (FVector2D Axis :
             {FVector2D(FMath::Cos(Yaw), -FMath::Sin(Yaw)), FVector2D(FMath::Sin(Yaw), FMath::Cos(Yaw))})
        {
            double AMin = DBL_MAX, AMax = -DBL_MAX, BMin = DBL_MAX, BMax = -DBL_MAX;
            for (const auto &P : CA)
            {
                const double D = FVector2D::DotProduct(P, Axis);
                AMin = FMath::Min(AMin, D);
                AMax = FMath::Max(AMax, D);
            }
            for (const auto &P : CB)
            {
                const double D = FVector2D::DotProduct(P, Axis);
                BMin = FMath::Min(BMin, D);
                BMax = FMath::Max(BMax, D);
            }
            if (AMax <= BMin + .001 || BMax <= AMin + .001)
                return false;
        }
    return true;
}
TArray<FWarning> Warnings(const FScene &S)
{
    TArray<FWarning> R;
    for (int32 I = 0; I < S.Items.Num(); ++I)
    {
        const FItem &Item = S.Items[I];
        for (const auto &P : Corners(Item))
            if (P.X < 0 || P.Y < 0 || P.X > S.Width || P.Y > S.Depth)
            {
                R.Add({Item.Id, FGuid(), TEXT("部屋からのはみ出し（外形候補）")});
                break;
            }
        for (int32 J = I + 1; J < S.Items.Num(); ++J)
            if (Overlap(Item, S.Items[J]))
                R.Add({Item.Id, S.Items[J].Id, TEXT("家具の重なり候補（外形箱）")});
    }
    return R;
}
static bool Keys(const TSharedPtr<FJsonObject> &O, std::initializer_list<const TCHAR *> Names)
{
    if (!O.IsValid() || O->Values.Num() != static_cast<int32>(Names.size()))
        return false;
    for (const TCHAR *K : Names)
        if (!O->HasField(K))
            return false;
    return true;
}
FString Encode(const FScene &S)
{
    const auto Root = MakeShared<FJsonObject>();
    Root->SetStringField(TEXT("format"), TEXT("yohaku-local-study"));
    Root->SetNumberField(TEXT("version"), 1);
    auto Room = MakeShared<FJsonObject>();
    Room->SetNumberField(TEXT("widthMm"), S.Width);
    Room->SetNumberField(TEXT("depthMm"), S.Depth);
    Room->SetNumberField(TEXT("heightMm"), S.Height);
    Root->SetObjectField(TEXT("room"), Room);
    TArray<TSharedPtr<FJsonValue>> Finishes;
    for (int32 F : S.Finishes)
        Finishes.Add(MakeShared<FJsonValueNumber>(F));
    Root->SetArrayField(TEXT("finishes"), Finishes);
    TArray<TSharedPtr<FJsonValue>> Items;
    for (const FItem &I : S.Items)
    {
        auto O = MakeShared<FJsonObject>();
        O->SetStringField(TEXT("id"), I.Id.ToString(EGuidFormats::DigitsWithHyphens));
        O->SetStringField(TEXT("assetVersionId"), VariantId(I.Variant));
        O->SetNumberField(TEXT("xMm"), I.X);
        O->SetNumberField(TEXT("zMm"), I.Z);
        O->SetNumberField(TEXT("yawRad"), I.Yaw);
        Items.Add(MakeShared<FJsonValueObject>(O));
    }
    Root->SetArrayField(TEXT("furniture"), Items);
    FString Out;
    const auto Writer = TJsonWriterFactory<>::Create(&Out);
    FJsonSerializer::Serialize(Root, Writer);
    return Out;
}
bool Decode(const FString &Text, FScene &Out, FString &Error)
{
    Error = TEXT("ファイル形式が不正です。現在のレイアウトは保持しました");
    if (Text.Len() > 4 * 1024 * 1024)
        return false;
    TSharedPtr<FJsonObject> Root;
    auto Reader = TJsonReaderFactory<>::Create(Text);
    if (!FJsonSerializer::Deserialize(Reader, Root) ||
        !Keys(Root, {TEXT("format"), TEXT("version"), TEXT("room"), TEXT("finishes"), TEXT("furniture")}))
        return false;
    FString Format;
    double Version = 0;
    if (!Root->TryGetStringField(TEXT("format"), Format) || Format != TEXT("yohaku-local-study") ||
        !Root->TryGetNumberField(TEXT("version"), Version) || Version != 1)
        return false;
    const TSharedPtr<FJsonObject> *Room;
    if (!Root->TryGetObjectField(TEXT("room"), Room) ||
        !Keys(*Room, {TEXT("widthMm"), TEXT("depthMm"), TEXT("heightMm")}))
        return false;
    FScene Candidate;
    if (!(*Room)->TryGetNumberField(TEXT("widthMm"), Candidate.Width) ||
        !(*Room)->TryGetNumberField(TEXT("depthMm"), Candidate.Depth) ||
        !(*Room)->TryGetNumberField(TEXT("heightMm"), Candidate.Height))
        return false;
    const TArray<TSharedPtr<FJsonValue>> *Finishes, *Items;
    if (!Root->TryGetArrayField(TEXT("finishes"), Finishes) || Finishes->Num() != 5 ||
        !Root->TryGetArrayField(TEXT("furniture"), Items) || Items->Num() > 200)
        return false;
    Candidate.Finishes.Reset();
    for (const auto &V : *Finishes)
    {
        double F;
        if (!V->TryGetNumber(F) || !FiniteRange(F, 0, 4) || F != FMath::FloorToDouble(F))
            return false;
        Candidate.Finishes.Add(static_cast<int32>(F));
    }
    for (const auto &V : *Items)
    {
        if (V->Type != EJson::Object)
            return false;
        auto O = V->AsObject();
        if (!Keys(O, {TEXT("id"), TEXT("assetVersionId"), TEXT("xMm"), TEXT("zMm"), TEXT("yawRad")}))
            return false;
        FItem I;
        FString Id, Asset;
        if (!O->TryGetStringField(TEXT("id"), Id) || !FGuid::ParseExact(Id, EGuidFormats::DigitsWithHyphens, I.Id) ||
            !O->TryGetStringField(TEXT("assetVersionId"), Asset) || !O->TryGetNumberField(TEXT("xMm"), I.X) ||
            !O->TryGetNumberField(TEXT("zMm"), I.Z) || !O->TryGetNumberField(TEXT("yawRad"), I.Yaw))
            return false;
        if (Asset == VariantId(EVariant::Brown))
            I.Variant = EVariant::Brown;
        else if (Asset == VariantId(EVariant::BlueGray))
            I.Variant = EVariant::BlueGray;
        else
        {
            Error = TEXT("未対応の家具版です。現在のレイアウトは保持しました");
            return false;
        }
        Candidate.Items.Add(I);
    }
    if (!Validate(Candidate, Error))
        return false;
    Candidate.Width = Normalize(Candidate.Width);
    Candidate.Depth = Normalize(Candidate.Depth);
    Candidate.Height = Normalize(Candidate.Height);
    for (FItem &I : Candidate.Items)
    {
        I.X = Normalize(I.X);
        I.Z = Normalize(I.Z);
        I.Yaw = Angle(I.Yaw);
    }
    Out = MoveTemp(Candidate);
    Error.Reset();
    return true;
}
bool FDocument::Commit(const FEdit &Edit, FString &Error)
{
    FScene Next;
    if (!Apply(Scene, Edit, Next, Error))
        return false;
    if (Next == Scene)
        return true;
    Past.Add(Scene);
    if (Past.Num() > 100)
        Past.RemoveAt(0);
    Future.Reset();
    Scene = MoveTemp(Next);
    return true;
}
bool FDocument::Undo()
{
    if (Past.IsEmpty())
        return false;
    Future.Add(Scene);
    Scene = Past.Pop();
    return true;
}
bool FDocument::Redo()
{
    if (Future.IsEmpty())
        return false;
    Past.Add(Scene);
    Scene = Future.Pop();
    return true;
}
bool FDocument::ReplaceLoaded(const FString &Json, FString &Error)
{
    FScene Candidate;
    if (!Decode(Json, Candidate, Error))
        return false;
    Scene = MoveTemp(Candidate);
    Past.Reset();
    Future.Reset();
    MarkSaved();
    return true;
}
} // namespace Yohaku
