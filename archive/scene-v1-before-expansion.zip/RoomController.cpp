#include "RoomController.h"
#include "SceneProjection.h"
#include "RoomEditorWidget.h"
#include "LayoutStorage.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "Engine/GameViewportClient.h"
#include "Engine/World.h"
#include "Engine/Engine.h"
#include "Components/BoxComponent.h"
#include "Misc/CommandLine.h"
#include "Misc/Parse.h"
#include "DrawDebugHelpers.h"
#include "TimerManager.h"
#include "HAL/FileManager.h"
#include "Misc/MessageDialog.h"
#include "Misc/App.h"
#include "InputKeyEventArgs.h"
#include "ProductResearch.h"

ARoomController::ARoomController()
{
    bShowMouseCursor = true;
    PrimaryActorTick.bCanEverTick = true;
}
void ARoomController::BeginPlay()
{
    Super::BeginPlay();
    Research = MakeShared<FProductResearch, ESPMode::ThreadSafe>();
    Projection = GetWorld()->SpawnActor<AYSceneProjection>();
    ViewCamera = GetWorld()->SpawnActor<ACameraActor>();
    ViewCamera->GetCameraComponent()->SetFieldOfView(48);
    SetViewTarget(ViewCamera);
    FInputModeGameAndUI Mode;
    Mode.SetHideCursorDuringCapture(false);
    Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
    SetInputMode(Mode);
    if (GEngine && GEngine->GameViewport)
    {
        SAssignNew(Widget, SRoomEditor).Controller(this);
        GEngine->GameViewport->AddViewportWidgetContent(Widget.ToSharedRef(), 10);
        GEngine->GameViewport->OnWindowCloseRequested().BindUObject(this, &ARoomController::ConfirmClose);
    }
    if (!FParse::Param(FCommandLine::Get(), TEXT("YohakuSmoke")) &&
        IFileManager::Get().FileExists(*Yohaku::FLayoutStorage::Path()))
    {
        FString Json, Error;
        if (Yohaku::FLayoutStorage::Load(Json, Error) && Document.ReplaceLoaded(Json, Error))
            Notice = TEXT("このPCに保存したレイアウトを復元しました");
        else
            Notice = Error;
    }
    Refresh();
    UpdateCamera();
    bSmoke = FParse::Param(FCommandLine::Get(), TEXT("YohakuSmoke")) ||
             FParse::Param(FCommandLine::Get(), TEXT("YohakuReloadSmoke"));
    if (bSmoke)
    {
        FTimerHandle Handle;
        GetWorldTimerManager().SetTimer(Handle, this, &ARoomController::RunSmokeTest, 4, false);
    }
    if (FParse::Param(FCommandLine::Get(), TEXT("YohakuProductSmoke")) ||
        FParse::Param(FCommandLine::Get(), TEXT("YohakuCandidateReloadSmoke")))
    {
        FTimerHandle Handle;
        GetWorldTimerManager().SetTimer(Handle, this, &ARoomController::RunProductSmokeTest, 4, false);
    }
}
void ARoomController::EndPlay(const EEndPlayReason::Type Reason)
{
    if (Research)
        Research->Cancel();
    Research.Reset();
    if (GEngine && GEngine->GameViewport)
        GEngine->GameViewport->OnWindowCloseRequested().Unbind();
    if (Widget.IsValid() && GEngine && GEngine->GameViewport)
        GEngine->GameViewport->RemoveViewportWidgetContent(Widget.ToSharedRef());
    Widget.Reset();
    Super::EndPlay(Reason);
}

bool ARoomController::ConfirmClose()
{
    if (!Document.Dirty())
        return true;
    if (FApp::IsUnattended())
        return false;
    const EAppReturnType::Type Choice =
        FMessageDialog::Open(EAppMsgType::YesNoCancel,
                             FText::FromString(TEXT("未保存の変更があります。保存して終了しますか？\nはい：保存して終了"
                                                    "\nいいえ：変更を破棄\nキャンセル：編集に戻る")),
                             FText::FromString(TEXT("余白 — レイアウトの保存")));
    if (Choice == EAppReturnType::Yes)
    {
        Save();
        return !Document.Dirty();
    }
    return Choice == EAppReturnType::No;
}
bool ARoomController::InputKey(const FInputKeyEventArgs &Params)
{
    const bool Handled = Super::InputKey(Params);
    const FKey Key = Params.Key;
    if (Key == EKeys::LeftControl || Key == EKeys::RightControl || Key == EKeys::LeftShift || Key == EKeys::RightShift)
    {
        if (Params.Event == IE_Pressed)
            ModifierKeys.Add(Key);
        else if (Params.Event == IE_Released)
            ModifierKeys.Remove(Key);
        return Handled;
    }
    if (!Projection || !ViewCamera)
        return Handled;
    // Dispatch while the viewport still holds this event's cursor and modifier state.
    // Tick-based bindings lose both when press/move/release arrive in one frame.
    if (Params.Event == IE_Released)
    {
        if (Key == EKeys::LeftMouseButton)
        {
            LeftUp();
            return true;
        }
        if (Key == EKeys::RightMouseButton)
        {
            RightUp();
            return true;
        }
        return Handled;
    }
    if (Params.Event != IE_Pressed && Params.Event != IE_DoubleClick)
        return Handled;
    if (Key == EKeys::LeftMouseButton)
    {
        LeftDown();
        return true;
    }
    if (Key == EKeys::RightMouseButton)
    {
        RightDown();
        return true;
    }
    if (Key == EKeys::MouseScrollUp)
    {
        ZoomIn();
        return true;
    }
    if (Key == EKeys::MouseScrollDown)
    {
        ZoomOut();
        return true;
    }
    if (Key == EKeys::Escape)
    {
        Cancel();
        return true;
    }
    const bool Ctrl = ModifierKeys.Contains(EKeys::LeftControl) || ModifierKeys.Contains(EKeys::RightControl);
    const bool Shift = ModifierKeys.Contains(EKeys::LeftShift) || ModifierKeys.Contains(EKeys::RightShift);
    if (Ctrl)
    {
        if (Key == EKeys::Z)
        {
            if (Shift)
                Redo();
            else
                Undo();
            return true;
        }
        if (Key == EKeys::Y)
        {
            Redo();
            return true;
        }
        if (Key == EKeys::S)
        {
            Save();
            return true;
        }
        if (Key == EKeys::O)
        {
            Load();
            return true;
        }
    }
    else
    {
        if (Key == EKeys::R)
        {
            Rotate();
            return true;
        }
        if (Key == EKeys::Delete)
        {
            DeleteSelected();
            return true;
        }
    }
    return Handled;
}
void ARoomController::FlushPressedKeys()
{
    Super::FlushPressedKeys();
    ModifierKeys.Reset();
    bOrbit = false;
    Cancel();
}
bool ARoomController::FloorPoint(FVector2D &Out) const
{
    FVector Origin, Direction;
    if (!DeprojectMousePositionToWorld(Origin, Direction) || FMath::Abs(Direction.Z) < .00001)
        return false;
    const double T = -Origin.Z / Direction.Z;
    if (T < 0)
        return false;
    const FVector P = Origin + Direction * T;
    Out = FVector2D(P.X * 10, P.Y * 10);
    return true;
}
const Yohaku::FItem *ARoomController::SelectedItem() const
{
    return Document.Get().Items.FindByPredicate([&](const auto &I) { return I.Id == Selected; });
}
void ARoomController::Refresh()
{
    Projection->Reconcile(Document.Get(), Selected);
    if (!SelectedItem())
        Selected.Invalidate();
}
bool ARoomController::Execute(const Yohaku::FEdit &E)
{
    LoadArmedUntil = 0;
    FString Error;
    if (!Document.Commit(E, Error))
    {
        Notice = Error.IsEmpty() ? TEXT("操作を適用できません") : Error;
        return false;
    }
    Notice.Reset();
    Refresh();
    return true;
}
void ARoomController::StartPlacement(Yohaku::EVariant V)
{
    Cancel();
    Tool = ERoomTool::Place;
    Preview = Yohaku::FItem();
    Preview.Variant = V;
    Preview.Yaw = PI;
    Notice = TEXT("床をクリックして配置 / Escで中止");
}
void ARoomController::SetTool(ERoomTool T)
{
    Cancel();
    Tool = T;
    if (T == ERoomTool::DrawRoom)
    {
        View(1);
        Notice = TEXT("床面を対角にドラッグして部屋を作成。寸法は入力値です");
    }
}
void ARoomController::LeftDown()
{
    if (bOrbit)
        return;
    FVector2D P;
    if (!FloorPoint(P))
        return;
    if (Tool == ERoomTool::Place)
    {
        UpdatePointerPose();
        Yohaku::FEdit E;
        E.Type = Yohaku::EEditType::Add;
        E.Item = Preview;
        if (Execute(E))
        {
            Selected = Preview.Id;
            Tool = ERoomTool::Select;
            Projection->HideGhost();
            Refresh();
        }
        return;
    }
    if (Tool == ERoomTool::DrawRoom)
    {
        bDrawing = true;
        DrawStart = P;
        return;
    }
    FHitResult Hit;
    GetHitResultUnderCursor(ECC_Visibility, false, Hit);
    auto *Actor = Cast<AYFurnitureActor>(Hit.GetActor());
    Selected = Actor ? Actor->InstanceId : FGuid();
    Refresh();
    if (const auto *I = SelectedItem())
    {
        Preview = *I;
        GrabOffset = FVector2D(I->X, I->Z) - P;
        float X = 0, Y = 0;
        GetMousePosition(X, Y);
        DragPointerStart = FVector2D(X, Y);
        bDragMoved = false;
        bDragging = true;
    }
}
void ARoomController::LeftUp()
{
    if (bDragging)
    {
        UpdatePointerPose();
        CommitDrag();
    }
    if (bDrawing)
    {
        bDrawing = false;
        FVector2D P;
        if (FloorPoint(P))
        {
            SetRoom(FMath::Clamp(FMath::Abs(P.X - DrawStart.X), 500.0, 30000.0),
                    FMath::Clamp(FMath::Abs(P.Y - DrawStart.Y), 500.0, 30000.0), Document.Get().Height);
        }
        Tool = ERoomTool::Select;
    }
}
void ARoomController::CommitDrag()
{
    bDragging = false;
    Yohaku::FEdit E;
    E.Type = Yohaku::EEditType::Move;
    E.Target = Selected;
    E.Item = Preview;
    Execute(E);
}
void ARoomController::RightDown()
{
    bOrbit = true;
    float X, Y;
    GetMousePosition(X, Y);
    LastMouse = FVector2D(X, Y);
}
void ARoomController::RightUp()
{
    UpdateOrbit();
    bOrbit = false;
}
void ARoomController::UpdateOrbit()
{
    if (bOrbit)
    {
        float X, Y;
        if (GetMousePosition(X, Y))
        {
            const FVector2D Delta = FVector2D(X, Y) - LastMouse;
            LastMouse = FVector2D(X, Y);
            if (ModifierKeys.Contains(EKeys::LeftShift) || ModifierKeys.Contains(EKeys::RightShift))
            {
                const FVector Right = ViewCamera->GetActorRightVector(),
                              Forward = FVector::CrossProduct(FVector::UpVector, Right);
                CameraTarget -= Right * Delta.X * Distance * .001;
                CameraTarget += Forward * Delta.Y * Distance * .001;
            }
            else
            {
                OrbitYaw -= Delta.X * .25;
                OrbitPitch = FMath::Clamp(OrbitPitch + Delta.Y * .2, 15.0, 89.0);
            }
            UpdateCamera();
        }
    }
}
void ARoomController::UpdatePointerPose()
{
    FVector2D P;
    if ((Tool == ERoomTool::Place || bDragging) && !bOrbit && FloorPoint(P))
    {
        if (bDragging)
        {
            float X = 0, Y = 0;
            if (!GetMousePosition(X, Y))
                return;
            if (!bDragMoved && FVector2D::DistSquared(DragPointerStart, FVector2D(X, Y)) < 9.0)
                return;
            bDragMoved = true;
            P += GrabOffset;
        }
        const double Step = bSnap ? 100 : 0.001;
        Preview.X = FMath::GridSnap(P.X, Step);
        Preview.Z = FMath::GridSnap(P.Y, Step);
        if (bDragging)
            Projection->PreviewPose(Preview);
        else
            Projection->ShowGhost(Preview);
    }
}
void ARoomController::PlayerTick(float Dt)
{
    Super::PlayerTick(Dt);
    UpdateOrbit();
    UpdatePointerPose();
    FVector2D P;
    if (Tool == ERoomTool::Place || bDragging)
    {
        const FVector A(Preview.X / 10, Preview.Z / 10, 41);
        DrawDebugBox(GetWorld(), A, FVector(75, 43.5, 41), FQuat(FRotator(0, -FMath::RadiansToDegrees(Preview.Yaw), 0)),
                     FColor(180, 215, 140), false, -1, 0, 1.1);
    }
    if (bDrawing && FloorPoint(P))
    {
        const FVector A(DrawStart.X / 10, DrawStart.Y / 10, 1), B(P.X / 10, P.Y / 10, 1);
        DrawDebugBox(GetWorld(), (A + B) / 2, FVector(FMath::Abs(A.X - B.X) / 2, FMath::Abs(A.Y - B.Y) / 2, 1),
                     FColor(150, 210, 170), false, -1, 0, 2);
    }
    if (const auto *I = SelectedItem())
    {
        const auto &Pose = bDragging ? Preview : *I;
        DrawDebugBox(GetWorld(), FVector(Pose.X / 10, Pose.Z / 10, 41), FVector(75, 43.5, 41),
                     FQuat(FRotator(0, -FMath::RadiansToDegrees(Pose.Yaw), 0)), FColor(165, 205, 130), false, -1, 0, 1);
    }
    Projection->Cutaway(ViewCamera->GetActorLocation());
}
void ARoomController::UpdateCamera()
{
    const double Y = FMath::DegreesToRadians(OrbitYaw), P = FMath::DegreesToRadians(OrbitPitch);
    const FVector At =
        CameraTarget + Distance * FVector(FMath::Cos(P) * FMath::Cos(Y), FMath::Cos(P) * FMath::Sin(Y), FMath::Sin(P));
    ViewCamera->SetActorLocation(At);
    ViewCamera->SetActorRotation((CameraTarget - At).Rotation());
}
void ARoomController::ZoomIn()
{
    Distance = FMath::Clamp(Distance * .9, 120.0, 4000.0);
    UpdateCamera();
}
void ARoomController::ZoomOut()
{
    Distance = FMath::Clamp(Distance / .9, 120.0, 4000.0);
    UpdateCamera();
}
void ARoomController::View(int32 P)
{
    CameraTarget = FVector(Document.Get().Width / 20, Document.Get().Depth / 20, 45);
    OrbitPitch = P == 1 ? 89 : P == 2 ? 18 : 54;
    Distance = P == 2 ? 480 : FMath::Max(Document.Get().Width, Document.Get().Depth) / 10 * 1.7;
    OrbitYaw = -90;
    UpdateCamera();
}
void ARoomController::SetRoom(double W, double D, double H)
{
    Cancel();
    Yohaku::FEdit E;
    E.Type = Yohaku::EEditType::Room;
    E.Width = W;
    E.Depth = D;
    E.Height = H;
    if (Execute(E))
        View(0);
}
void ARoomController::SetFinish(int32 F)
{
    Cancel();
    Yohaku::FEdit E;
    E.Type = Yohaku::EEditType::Surface;
    E.Surface = Surface;
    E.Finish = F;
    Execute(E);
}
void ARoomController::EditPose(double X, double Z, double Yaw)
{
    if (!SelectedItem())
        return;
    Cancel();
    Yohaku::FEdit E;
    E.Type = Yohaku::EEditType::Move;
    E.Target = Selected;
    E.Item = *SelectedItem();
    E.Item.X = X;
    E.Item.Z = Z;
    E.Item.Yaw = FMath::DegreesToRadians(Yaw);
    Execute(E);
}
void ARoomController::ChangeVariant(Yohaku::EVariant V)
{
    if (!SelectedItem())
        return;
    Cancel();
    Yohaku::FEdit E;
    E.Type = Yohaku::EEditType::Variant;
    E.Target = Selected;
    E.Item.Variant = V;
    Execute(E);
}
void ARoomController::Rotate()
{
    if (Tool == ERoomTool::Place)
    {
        Preview.Yaw += PI / 4;
        return;
    }
    if (const auto *I = SelectedItem())
        EditPose(I->X, I->Z, FMath::RadiansToDegrees(I->Yaw) + 45);
}
void ARoomController::Duplicate()
{
    if (!SelectedItem())
        return;
    Cancel();
    Yohaku::FEdit E;
    E.Type = Yohaku::EEditType::Duplicate;
    E.Target = Selected;
    E.Item.Id = FGuid::NewGuid();
    E.Item.X = SelectedItem()->X + 200;
    E.Item.Z = SelectedItem()->Z + 200;
    if (Execute(E))
    {
        Selected = E.Item.Id;
        Refresh();
    }
}
void ARoomController::DeleteSelected()
{
    if (!SelectedItem())
        return;
    Cancel();
    Yohaku::FEdit E;
    E.Type = Yohaku::EEditType::Remove;
    E.Target = Selected;
    Execute(E);
    Selected.Invalidate();
}
void ARoomController::Undo()
{
    Cancel();
    Document.Undo();
    Refresh();
}
void ARoomController::Redo()
{
    Cancel();
    Document.Redo();
    Refresh();
}
void ARoomController::Cancel()
{
    bDragging = false;
    bDrawing = false;
    Tool = ERoomTool::Select;
    if (Projection)
    {
        Projection->HideGhost();
        Refresh();
    }
    Notice.Reset();
}
void ARoomController::Save()
{
    Cancel();
    FString Error;
    if (Yohaku::FLayoutStorage::Save(Yohaku::Encode(Document.Get()), Error))
    {
        Document.MarkSaved();
        Notice = TEXT("このPCに保存しました");
    }
    else
        Notice = Error;
}
void ARoomController::Load()
{
    if (Document.Dirty() && LoadArmedUntil < GetWorld()->GetTimeSeconds())
    {
        LoadArmedUntil = GetWorld()->GetTimeSeconds() + 6;
        Notice = TEXT("未保存の変更があります。6秒以内にもう一度「読込」で破棄して読み込みます");
        return;
    }
    LoadArmedUntil = 0;
    Cancel();
    FString Json, Error;
    if (Yohaku::FLayoutStorage::Load(Json, Error) && Document.ReplaceLoaded(Json, Error))
    {
        Selected.Invalidate();
        Refresh();
        View(0);
        Notice = TEXT("保存したレイアウトを読み込みました");
    }
    else
        Notice = Error;
}
FString ARoomController::Status() const
{
    const auto W = Yohaku::Warnings(Document.Get());
    const FString Message = !Notice.IsEmpty() ? Notice
                            : W.IsEmpty()     ? TEXT("検証用レイアウト / PSFモデルは実物校正前")
                                              : W[0].Message;
    return FString::Printf(TEXT("%s  |  %d点  |  %d件の外形警告\n%s"),
                           Document.Dirty() ? TEXT("未保存") : TEXT("このPCに保存済み"), Document.Get().Items.Num(),
                           W.Num(), *Message);
}
