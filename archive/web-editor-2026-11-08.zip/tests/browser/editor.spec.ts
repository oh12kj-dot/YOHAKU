import { expect, test, type Page } from '@playwright/test';

async function placeSofa(page: Page) {
  await page.getByRole('button', { name: '真上', exact: true }).click();
  await page.getByRole('button', { name: 'ラウンジソファを配置', exact: true }).click();
  const box = (await page.locator('canvas').boundingBox())!;
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2);
  await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  await expect(page.getByRole('spinbutton', { name: 'X位置', exact: true })).toBeVisible();
  return { x: box.x + box.width / 2, y: box.y + box.height / 2 };
}

test('3D furniture placement, fixed variant replacement, rotation, duplicate, delete, undo and redo', async ({ page }) => {
  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  await page.goto('/');
  await expect(page.locator('canvas')).toBeVisible();
  await placeSofa(page);
  const x = await page.getByRole('spinbutton', { name: 'X位置', exact: true }).inputValue();
  const z = await page.getByRole('spinbutton', { name: 'Z位置', exact: true }).inputValue();
  await page.getByRole('button', { name: '色をモスグリーンに変更' }).click();
  await expect(page.getByText('操作サンプル · モスグリーン', { exact: true })).toBeVisible();
  await expect(page.getByRole('spinbutton', { name: 'X位置', exact: true })).toHaveValue(x);
  await expect(page.getByRole('spinbutton', { name: 'Z位置', exact: true })).toHaveValue(z);
  await expect(page.getByText('W 1800 × D 850 × H 800 mm', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '↷ ＋45°', exact: true }).click();
  await expect(page.getByRole('spinbutton', { name: '回転角', exact: true })).toHaveValue('45');
  await page.getByRole('button', { name: '複製', exact: true }).click();
  await expect(page.getByText('／ 2点の家具', { exact: true })).toBeVisible();
  await expect(page.getByText('外形の衝突候補があります', { exact: false }).first()).toBeVisible();
  await page.getByRole('button', { name: '削除', exact: true }).click();
  await expect(page.getByText('／ 1点の家具', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '元に戻す', exact: true }).click();
  await expect(page.getByText('／ 2点の家具', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'やり直す', exact: true }).click();
  await expect(page.getByText('／ 1点の家具', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '俯瞰', exact: true }).click();
  await page.screenshot({ path: 'artifacts/builder-furniture.png', fullPage: true });
  expect(errors).toEqual([]);
});

test('drag commits one movement, Undo restores it, camera gestures preserve furniture', async ({ page }) => {
  await page.goto('/'); const point = await placeSofa(page);
  const xInput = page.getByRole('spinbutton', { name: 'X位置', exact: true }), zInput = page.getByRole('spinbutton', { name: 'Z位置', exact: true });
  const before = { x: await xInput.inputValue(), z: await zInput.inputValue() };
  await page.mouse.move(point.x, point.y); await page.mouse.down();
  await page.mouse.move(point.x + 55, point.y + 35, { steps: 8 });
  await expect(xInput).toHaveValue(before.x); // drag is preview, not a stream of commits
  await page.mouse.up();
  await expect(xInput).not.toHaveValue(before.x);
  await page.getByRole('button', { name: '元に戻す', exact: true }).click();
  await expect(xInput).toHaveValue(before.x); await expect(zInput).toHaveValue(before.z);
  await expect(page.getByText('／ 1点の家具', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: '視点', exact: true }).click();
  await page.mouse.move(point.x, point.y); await page.mouse.down(); await page.mouse.move(point.x + 60, point.y - 20, { steps: 7 }); await page.mouse.up();
  await expect(xInput).toHaveValue(before.x); await expect(zInput).toHaveValue(before.z);
});

test('room width drag previews then commits mm, undo restores size; number inputs reject negatives', async ({ page }) => {
  await page.goto('/'); await page.getByRole('button', { name: '部屋を描く', exact: true }).click();
  await expect(page.getByText('仮のサイズ', { exact: true })).toBeVisible();
  const handle = page.getByTestId('resize-width'); const box = (await handle.boundingBox())!;
  const destination = await page.locator('.plan-svg').evaluate((svg: SVGSVGElement) => {
    const point = new DOMPoint(5000, 1750).matrixTransform(svg.getScreenCTM()!); return { x: point.x, y: point.y };
  });
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2); await page.mouse.down(); await page.mouse.move(destination.x, destination.y, { steps: 6 });
  await expect(page.locator('.toolbar-size')).toHaveText('4,000 × 3,500 mm');
  await page.mouse.up(); await expect(page.locator('.toolbar-size')).toHaveText('5,000 × 3,500 mm');
  await page.getByRole('button', { name: '元に戻す', exact: true }).click(); await expect(page.locator('.toolbar-size')).toHaveText('4,000 × 3,500 mm');
  await page.getByRole('spinbutton', { name: '幅', exact: true }).fill('-1'); await page.getByRole('button', { name: '部屋に反映する', exact: true }).click();
  await expect(page.locator('.toolbar-size')).toHaveText('4,000 × 3,500 mm');
  await page.getByRole('spinbutton', { name: '幅', exact: true }).fill('5200'); await page.getByRole('button', { name: '部屋に反映する', exact: true }).click();
  await expect(page.locator('.toolbar-size')).toHaveText('5,200 × 3,500 mm');
  await expect(page.getByRole('button', { name: 'やり直す', exact: true })).toBeDisabled();
  await page.getByRole('button', { name: '3Dに戻る', exact: false }).click();
  await expect(page.getByText('18.20', { exact: true })).toBeVisible();
});

test('floor and all four stable walls accept separate finishes and undo', async ({ page }) => {
  await page.goto('/'); await page.getByRole('button', { name: '壁・床を選ぶ', exact: true }).click();
  await page.getByRole('button', { name: 'ウォールナット', exact: true }).click();
  await expect(page.getByRole('button', { name: 'ウォールナット', exact: true })).toHaveAttribute('aria-pressed', 'true');
  for (const wall of ['北の壁', '南の壁', '東の壁', '西の壁']) {
    await page.getByRole('button', { name: wall, exact: true }).click();
    await page.getByRole('button', { name: 'セージ', exact: true }).click();
    await expect(page.getByRole('button', { name: 'セージ', exact: true })).toHaveAttribute('aria-pressed', 'true');
  }
  await page.getByRole('button', { name: '元に戻す', exact: true }).click();
  await expect(page.getByRole('button', { name: 'アイボリー', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: '床', exact: true }).click();
  await expect(page.getByRole('button', { name: 'ウォールナット', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.screenshot({ path: 'artifacts/builder-finishes.png', fullPage: true });
});

test('real product source displays observed dimensions and photos per color without claiming generated model', async ({ page }) => {
  await page.goto('/'); await page.getByRole('button', { name: '↗ 商品URL', exact: false }).click();
  await expect(page.getByRole('heading', { name: 'JOURNAL STANDARD FURNITURE PSF SOFA 2P', exact: true })).toBeVisible();
  await expect(page.getByText('W 1500 × D 870 × H 820 mm', { exact: true })).toBeVisible();
  const photo = page.locator('.product-photo img'), brown = await photo.getAttribute('src');
  await page.getByRole('button', { name: 'ブルーグレー', exact: true }).click();
  await expect(photo).not.toHaveAttribute('src', brown!);
  await expect(photo).toHaveAttribute('alt', /ブルーグレー/);
  await expect.poll(() => photo.evaluate((img: HTMLImageElement) => img.naturalWidth)).toBeGreaterThan(0);
  await expect(page.getByRole('button', { name: '3D生成先の接続待ち', exact: true })).toBeDisabled();
  await expect(page.getByText('○ 自動復元モデル未生成', { exact: true })).toBeVisible();
  await expect(page.getByText('／ 空の部屋', { exact: true })).toBeVisible();
  await page.screenshot({ path: 'artifacts/builder-product-source.png', fullPage: true });
});

test('Escape cancels a placement without adding furniture', async ({ page }) => {
  await page.goto('/'); await page.getByRole('button', { name: 'ラウンジソファを配置', exact: true }).click();
  await page.keyboard.press('Escape'); await page.locator('canvas').click({ position: { x: 300, y: 350 } });
  await expect(page.getByText('／ 空の部屋', { exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: '元に戻す', exact: true })).toBeDisabled();
});

test('WebGL2 failure is explicit while room inputs remain usable', async ({ browser }) => {
  const context = await browser.newContext();
  await context.addInitScript(() => {
    const original = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (this: HTMLCanvasElement, type: string, ...args: unknown[]) { return type === 'webgl2' ? null : Reflect.apply(original, this, [type, ...args]); } as typeof original;
  });
  const page = await context.newPage(); await page.goto('/');
  await expect(page.getByRole('heading', { name: '3D表示を利用できません' })).toBeVisible();
  await page.getByRole('button', { name: '⌑ 部屋', exact: false }).click();
  await expect(page.getByRole('spinbutton', { name: '幅', exact: true })).toBeEnabled();
  await context.close();
});
