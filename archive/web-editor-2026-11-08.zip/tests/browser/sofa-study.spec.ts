import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';

test('photo-referenced sofa preview changes color, rotates and exports a real unvalidated GLB', async ({ page }) => {
  test.setTimeout(150000);
  const errors: string[] = []; page.on('pageerror', error => errors.push(error.message));
  await page.goto('/sofa-study.html');
  await expect(page.locator('canvas')).toBeVisible(); await expect(page.locator('#failure')).toBeHidden();
  await expect(page.getByText('写真からAIが自動復元したものではありません。', { exact: true })).toBeVisible();
  await expect(page.locator('#download')).toBeEnabled();
  await page.getByRole('button', { name: '正面', exact: true }).click();
  await page.getByRole('button', { name: '斜め', exact: true }).click();
  await page.screenshot({ path: 'artifacts/sofa-study-brown.png', fullPage: true });
  await page.getByRole('button', { name: '質感を拡大', exact: true }).click();
  await page.locator('#model-canvas').screenshot({ path: 'artifacts/sofa-study-material-detail.png' });
  await page.getByRole('button', { name: '斜め', exact: true }).click();
  for (const color of ['brown', 'blue-gray']) {
    if (color === 'blue-gray') await page.getByRole('button', { name: 'ブルーグレー', exact: true }).click();
    await expect(page.locator(`#${color}`)).toHaveAttribute('aria-pressed', 'true');
    const downloadPromise = page.waitForEvent('download'); await page.locator('#download').click(); const download = await downloadPromise;
    const path = `artifacts/psf-sofa-study-${color}-v2.glb`; await download.saveAs(path);
    expect(download.suggestedFilename()).toBe(`psf-sofa-study-${color}-v2.glb`);
    const file = await readFile(path);
    expect(file.subarray(0, 4).toString()).toBe('glTF'); expect(file.readUInt32LE(4)).toBe(2); expect(file.readUInt32LE(8)).toBe(file.length);
    const length = file.readUInt32LE(12), manifest = JSON.parse(file.subarray(20, 20 + length).toString());
    expect(manifest.nodes.some((node: { extras?: { placementEligible?: boolean; provenance?: string } }) => node.extras?.placementEligible === false && node.extras?.provenance === 'photo-referenced-code-model')).toBe(true);
    expect(manifest.meshes.length).toBeGreaterThan(10); expect(manifest.images.length).toBeGreaterThanOrEqual(3);
    expect(manifest.nodes.some((node: {extras?: {modelRevision?: number}}) => node.extras?.modelRevision === 2)).toBe(true);
    const fabric = manifest.materials.find((material: {name?: string}) => material.name === 'PSF_Upholstery_v2');
    expect(fabric.normalTexture).toBeTruthy(); expect(fabric.pbrMetallicRoughness.baseColorTexture).toBeTruthy(); expect(fabric.pbrMetallicRoughness.metallicRoughnessTexture).toBeTruthy();
    expect(manifest.extensionsUsed ?? []).not.toContain('EXT_materials_bump');
    await expect(page.getByRole('status')).toHaveText('未検証の試作モデルを書き出しました。');
  }
  await page.getByRole('button', { name: '背面', exact: true }).click(); await expect(page.locator('#rear')).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: '自動回転', exact: true }).click(); await expect(page.locator('#auto')).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: '斜め', exact: true }).click();
  await page.screenshot({ path: 'artifacts/sofa-study-blue-gray.png', fullPage: true });
  expect(errors).toEqual([]);
});
