import { describe, expect, it } from 'vitest';
import { catalog, catalogMap, defaultSurfaces } from '../packages/catalog/src/index';
import type { SceneDraft } from '../packages/contracts/src/index';
import { applyCommand } from '../packages/scene-domain/src/index';
import { commitLocal, createHistory, stepLocal } from '../packages/scene-domain/src/history';
import { parseFlymee, validateProductUrl } from '../workers/import/src/product-source';

const scene = (): SceneDraft => ({ schemaVersion: 1, layoutId: '20000000-0000-4000-8000-000000000001', room: { widthMm: 4000, depthMm: 3500, heightMm: 2400, columns: [] }, furniture: [], surfaces: defaultSurfaces(), geometryWarnings: [] });
describe('surface invariants', () => {
  it('changes one stable wall, preserves other walls and keeps input immutable', () => {
    const before = scene(); const next = applyCommand(before, { type: 'SetSurface', surface: { target: 'SOUTH', materialId: 'sage' } }, catalogMap);
    expect(next.surfaces.filter(s => s.materialId === 'sage')).toEqual([{ target: 'SOUTH', materialId: 'sage' }]);
    expect(next.surfaces).toHaveLength(5); expect(before.surfaces).toEqual(defaultSurfaces());
    const resized = applyCommand(next, { type: 'SetRoom', room: { ...next.room, widthMm: 5000 } }, catalogMap);
    expect(resized.surfaces).toEqual(next.surfaces);
  });
  it.each([{ target: 'FLOOR', materialId: 'sage' }, { target: 'NORTH', materialId: 'walnut' }, { target: 'NORTH', materialId: 'https://example.com/image.jpg' }, { target: 'FLOOR', materialId: 'stone', script: 'alert(1)' }])('rejects wrong target, external resources and unknown fields: %j', surface => {
    expect(() => applyCommand(scene(), { type: 'SetSurface', surface }, catalogMap)).toThrow();
  });
});
describe('tab-only undo', () => {
  it('restores the whole local state and invalidates redo on a new edit', () => {
    let h = createHistory(scene());
    h = commitLocal(h, { type: 'SetSurface', surface: { target: 'NORTH', materialId: 'clay' } }, catalogMap);
    h = commitLocal(h, { type: 'AddFurniture', furniture: { instanceId: '20000000-0000-4000-8000-000000000002', assetVersionId: catalog[0].assetVersionId, positionMm: { x: 1200, y: 0, z: 1200 }, yawRad: 0 } }, catalogMap);
    h = stepLocal(h, 'undo', catalogMap); expect(h.present.furniture).toHaveLength(0); expect(h.present.surfaces.find(s => s.target === 'NORTH')?.materialId).toBe('clay');
    h = stepLocal(h, 'redo', catalogMap); expect(h.present.furniture).toHaveLength(1);
    h = stepLocal(h, 'undo', catalogMap); h = commitLocal(h, { type: 'SetRoom', room: { ...h.present.room, heightMm: 2500 } }, catalogMap);
    expect(h.future).toHaveLength(0); expect(stepLocal(h, 'redo', catalogMap)).toBe(h);
  });
  it('ignores no-op commands and keeps failed edits out of history', () => {
    const h = createHistory(scene()); expect(commitLocal(h, { type: 'SetRoom', room: h.present.room }, catalogMap)).toBe(h);
    expect(commitLocal(h, { type: 'SetSurface', surface: { target: 'FLOOR', materialId: 'oak-natural' } }, catalogMap)).toBe(h);
    expect(() => commitLocal(h, { type: 'SetRoom', room: { ...h.present.room, widthMm: -1 } }, catalogMap)).toThrow();
    expect(h.past).toHaveLength(0);
  });
});
describe('product source extraction, not D/M gate approval', () => {
  const url = 'https://flymee.jp/product/106294/?pi_id=326211';
  const html = `<title>JOURNAL STANDARD FURNITURE PSF SOFA 2P / 商品名 - インテリア</title>
  <dl class="spec_area_table"><dd class="separate">ロータイプ脚部使用時：高さ70cm</dd></dl>
  <div class="spec_area_list _size"><span class="title">幅</span><span class="text">150cm</span></div>
  <div class="spec_area_list _size"><span class="title">奥行</span><span class="text">87cm</span></div>
  <div class="spec_area_list _size"><span class="title">高さ</span><span class="text">82cm</span></div>
  <div class="spec_area_list"><span class="title">座面高</span><span class="text">41cm</span></div>
  <li class="js-specHandler" data-spec-item-id="1"><span class="js-specItemName">ブラウン</span></li>
  <li class="js-specHandler" data-spec-item-id="2"><span class="js-specItemName">ブルーグレー</span></li>
  <img data-caption="張地：ブラウン" src="https://static2.flymee.jp/product_images/brown.jpg">
  <img data-caption="張地：ブルーグレー" src="https://static2.flymee.jp/product_images/blue.jpg">`;
  it('maps overall cm axes and exact color photos without claiming validated or generated', () => {
    const product = parseFlymee(html, url, '2026-11-07T00:00:00.000Z');
    expect(product.dimensions).toEqual({ widthMm: 1500, depthMm: 870, heightMm: 820 });
    expect(product.alternateConfiguration).toContain('高さ70cm');
    expect(product.variants.map(v => v.imageUrl)).toEqual(['https://static2.flymee.jp/product_images/brown.jpg', 'https://static2.flymee.jp/product_images/blue.jpg']);
    expect(product.dimensionStatus).toBe('single-source-unverified'); expect(product.modelStatus).toBe('not-generated'); expect(product.contentHash).toMatch(/^[a-f\d]{64}$/);
  });
  it('does not substitute another color photo or incomplete dimensions', () => {
    expect(parseFlymee(html.replace('張地：ブルーグレー', '張地：未知色'), url).variants[1].imageUrl).toBeNull();
    expect(() => parseFlymee(html.replace('82cm', '不明'), url)).toThrow('3軸');
    expect(() => parseFlymee(html + '<div class="spec_area_list _size"><span class="title">高さ</span><span class="text">70cm</span></div>', url)).toThrow('複数');
  });
  it.each(['http://flymee.jp/product/106294/', 'https://flymee.jp.evil.test/product/106294/', 'https://localhost/product/106294/', 'https://flymee.jp:9999/product/106294/', 'https://user:password@flymee.jp/product/106294/', 'https://flymee.jp/product/106294/?redirect=https://example.com', 'https://flymee.jp/guide/'])('rejects unsupported URLs %s', input => expect(() => validateProductUrl(input)).toThrow());
});
