import { describe, expect, it } from 'vitest';
import { envelopeSchema, type Asset, type Dimensions, type SceneDraft, type Wall } from '../packages/contracts/src/index';
import { applyCommand } from '../packages/scene-domain/src/index';
import { footprint, normalizeYaw, overlaps, replacementPosition, wallClearance } from '../packages/geometry-kernel/src/index';

const uuid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const size: Dimensions = { widthMm: 1000, depthMm: 600, heightMm: 800 };
const a: Asset = { assetVersionId: uuid(1), specVersionId: uuid(2), dimensions: size, specPolicy: 'eligible', assetPolicy: 'eligible', granted: true };
const b: Asset = { ...a, assetVersionId: uuid(3), dimensions: { widthMm: 1600, depthMm: 900, heightMm: 700 } };
const assets = new Map([[a.assetVersionId, a], [b.assetVersionId, b]]);
const instance = { instanceId: uuid(4), assetVersionId: a.assetVersionId, positionMm: { x: 1000, y: 0 as const, z: 1000 }, yawRad: 0 };
const empty = (): SceneDraft => ({ schemaVersion: 1, layoutId: uuid(5), room: { widthMm: 4000, depthMm: 3500, heightMm: 2400, columns: [] }, surfaces: [], furniture: [], geometryWarnings: [] });
const placed = () => applyCommand(empty(), { type: 'AddFurniture', furniture: instance }, assets);

describe('strict command boundary', () => {
  it.each([NaN, Infinity, -Infinity, 0, -1, 30001])('rejects invalid room width %s', widthMm => {
    expect(() => applyCommand(empty(), { type: 'SetRoom', room: { ...empty().room, widthMm } }, assets)).toThrow();
  });
  it('rejects positive dimensions that round to zero', () => {
    expect(() => applyCommand(empty(), { type: 'SetRoom', room: { ...empty().room, widthMm: 0.0001 } }, assets)).toThrow();
  });
  it('rejects snapshot injection, unknown fields, scale and floor lifting', () => {
    for (const command of [empty(), { type: 'AddFurniture', furniture: { ...instance, scale: 2 } }, { type: 'MoveFurniture', ...instance, positionMm: { x: 10, y: 100, z: 10 } }]) expect(() => applyCommand(empty(), command, assets)).toThrow();
  });
  it('keeps large revisions as decimal strings and rejects malformed envelopes', () => {
    expect(envelopeSchema.parse({ schemaVersion: 1, operationId: uuid(8), expectedRevision: '9007199254740993', command: { type: 'RemoveFurniture', instanceId: instance.instanceId } }).expectedRevision).toBe('9007199254740993');
    expect(envelopeSchema.safeParse({ schemaVersion: 1, operationId: uuid(8), expectedRevision: 1, command: { type: 'SetRoom', room: empty().room } }).success).toBe(false);
  });
});
describe('scene invariants', () => {
  it('keeps source immutable and normalizes position and yaw', () => {
    const source = placed();
    const next = applyCommand(source, { type: 'MoveFurniture', instanceId: instance.instanceId, positionMm: { x: 1500.12349, y: 0, z: 1200 }, yawRad: 3 * Math.PI }, assets);
    expect(source.furniture[0]).toEqual(instance);
    expect(next.furniture[0].positionMm.x).toBe(1500.123);
    expect(next.furniture[0].yawRad).toBeCloseTo(-Math.PI);
    expect(assets.get(a.assetVersionId)?.dimensions).toEqual(size);
  });
  it('preserves furniture and warns when room shrinks', () => {
    const source = placed();
    const next = applyCommand(source, { type: 'SetRoom', room: { ...source.room, widthMm: 800 } }, assets);
    expect(next.furniture).toEqual(source.furniture);
    expect(next.geometryWarnings[0]).toMatchObject({ kind: 'outside_room', shape: 'coarse' });
  });
  it.each(['specPolicy', 'assetPolicy'] as const)('rejects blocked %s for adoption but permits moving/removing existing placement', key => {
    const blocked = new Map(assets); blocked.set(a.assetVersionId, { ...a, [key]: 'blocked' });
    expect(() => applyCommand(empty(), { type: 'AddFurniture', furniture: instance }, blocked)).toThrow('新しく採用');
    expect(() => applyCommand(placed(), { type: 'DuplicateFurniture', sourceInstanceId: instance.instanceId, instanceId: uuid(9), positionMm: instance.positionMm }, blocked)).toThrow();
    expect(applyCommand(placed(), { type: 'MoveFurniture', instanceId: instance.instanceId, positionMm: instance.positionMm, yawRad: 0 }, blocked).furniture).toHaveLength(1);
    expect(applyCommand(placed(), { type: 'RemoveFurniture', instanceId: instance.instanceId }, blocked).furniture).toHaveLength(0);
  });
  it('rejects missing grants, duplicate IDs and stale replacement source', () => {
    const denied = new Map([[a.assetVersionId, { ...a, granted: false }]]);
    expect(() => applyCommand(empty(), { type: 'AddFurniture', furniture: instance }, denied)).toThrow();
    expect(() => applyCommand(placed(), { type: 'AddFurniture', furniture: instance }, assets)).toThrow('重複');
    expect(() => applyCommand(placed(), { type: 'ReplaceFurniture', instanceId: instance.instanceId, expectedAssetVersionId: b.assetVersionId, targetAssetVersionId: b.assetVersionId, anchor: 'center' }, assets)).toThrow('変更');
  });
  it('validates column range and warns on column collision', () => {
    const col = { columnId: uuid(6), xMm: 800, zMm: 800, widthMm: 200, depthMm: 200, heightMm: 2400 };
    const source = placed();
    const next = applyCommand(source, { type: 'SetRoom', room: { ...source.room, columns: [col] } }, assets);
    expect(next.geometryWarnings.some(w => w.kind === 'column_collision_candidate')).toBe(true);
    expect(() => applyCommand(source, { type: 'SetRoom', room: { ...source.room, columns: [{ ...col, xMm: 3999 }] } }, assets)).toThrow();
  });
  it('preserves center and yaw on center replacement', () => {
    const next = applyCommand(placed(), { type: 'ReplaceFurniture', instanceId: instance.instanceId, expectedAssetVersionId: a.assetVersionId, targetAssetVersionId: b.assetVersionId, anchor: 'center' }, assets);
    expect(next.furniture[0]).toEqual({ ...instance, assetVersionId: b.assetVersionId });
  });
  it('applies the wall anchor through the command and rejects blocked replacement targets', () => {
    const command = { type: 'ReplaceFurniture', instanceId: instance.instanceId, expectedAssetVersionId: a.assetVersionId, targetAssetVersionId: b.assetVersionId, anchor: 'wall', wallId: 'NORTH' };
    expect(applyCommand(placed(), command, assets).furniture[0].positionMm).toEqual({ x: 1000, y: 0, z: 1150 });
    const blocked = new Map(assets); blocked.set(b.assetVersionId, { ...b, specPolicy: 'blocked' });
    expect(() => applyCommand(placed(), command, blocked)).toThrow('新しく採用');
  });
  it('rejects a replacement whose computed position exceeds coordinate limits', () => {
    const source = applyCommand(placed(), { type: 'MoveFurniture', instanceId: instance.instanceId, positionMm: { x: 0, y: 0, z: 99999 }, yawRad: 0 }, assets);
    expect(() => applyCommand(source, { type: 'ReplaceFurniture', instanceId: instance.instanceId, expectedAssetVersionId: a.assetVersionId, targetAssetVersionId: b.assetVersionId, anchor: 'wall', wallId: 'NORTH' }, assets)).toThrow('計算後');
  });
});
describe('independent geometry expectations', () => {
  it('rotates with the right handed Three.js Y convention', () => {
    const points = footprint({ x: 1000, y: 0, z: 1000 }, Math.PI / 2, size);
    expect(Math.min(...points.map(p => p.x))).toBeCloseTo(700);
    expect(Math.max(...points.map(p => p.z))).toBeCloseTo(1500);
  });
  it('rejects AABB false positives for diagonal thin rectangles and treats touching as contact', () => {
    const thin = { widthMm: 2000, depthMm: 100, heightMm: 500 };
    const shape = footprint({ x: 0, y: 0, z: 0 }, Math.PI / 4, thin);
    expect(overlaps(shape, footprint({ x: 200, y: 0, z: 200 }, Math.PI / 4, thin))).toBe(false);
    expect(overlaps(footprint({ x: 0, y: 0, z: 0 }, 0, size), footprint({ x: 1000, y: 0, z: 0 }, 0, size))).toBe(false);
    expect(overlaps(shape, shape)).toBe(true);
  });
  it.each(['NORTH', 'SOUTH', 'EAST', 'WEST'] as Wall[])('preserves signed %s wall distance after rotated replacement', wall => {
    const item = { ...instance, positionMm: { x: -100, y: 0 as const, z: 200 }, yawRad: Math.PI / 3 };
    const old = wallClearance(item.positionMm, item.yawRad, size, empty().room, wall);
    const position = replacementPosition(item, size, b.dimensions, empty().room, wall);
    expect(wallClearance(position, item.yawRad, b.dimensions, empty().room, wall)).toBeCloseTo(old, 2);
    if (wall === 'NORTH' || wall === 'SOUTH') expect(position.x).toBe(item.positionMm.x);
    else expect(position.z).toBe(item.positionMm.z);
  });
  it('has a known independent north replacement coordinate', () => {
    expect(replacementPosition(instance, size, b.dimensions, empty().room, 'NORTH')).toEqual({ x: 1000, y: 0, z: 1150 });
  });
  it('normalizes very large finite yaw without overflow', () => {
    const yaw = normalizeYaw(Number.MAX_VALUE);
    expect(yaw).toBeGreaterThanOrEqual(-Math.PI);
    expect(yaw).toBeLessThan(Math.PI);
  });
});
