import { describe, expect, it } from 'vitest';
import * as THREE from 'three';
import { createSofaStudy } from '../apps/web/src/sofa-study-model';
import { disposeGroup } from '../apps/web/src/models';

describe('photo-referenced prototype, not an adopted asset', () => {
  it.each(['brown', 'blue-gray'] as const)('keeps %s model in the listed metre bounds with floor origin and explicit provenance', color => {
    const model = createSofaStudy(color), bounds = new THREE.Box3().setFromObject(model), size = bounds.getSize(new THREE.Vector3());
    expect(size.x).toBeCloseTo(1.5, 5); expect(size.y).toBeCloseTo(0.82, 5); expect(size.z).toBeCloseTo(0.87, 5);
    expect(bounds.min.y).toBeCloseTo(0, 6); expect(bounds.getCenter(new THREE.Vector3()).x).toBeCloseTo(0, 6);
    expect(model.userData.placementEligible).toBe(false); expect(model.userData.validationStatus).toBe('unvalidated');
    expect(model.userData.modelRevision).toBe(2);
    expect(model.getObjectByName('left-back-cushion')).toBeTruthy(); expect(model.getObjectByName('right-back-cushion')).toBeTruthy();
    model.traverse(o => { if (o instanceof THREE.Mesh) { const p = o.geometry.getAttribute('position'); for (let i = 0; i < p.count; i++) expect([p.getX(i), p.getY(i), p.getZ(i)].every(Number.isFinite)).toBe(true); } });
    disposeGroup(model);
  });
  it('has arched arm shoulders and retains the named, portable upholstery material', () => {
    const model = createSofaStudy('brown'), arm = model.getObjectByName('right-arm') as THREE.Mesh;
    const points = arm.geometry.getAttribute('position');
    let centreTop = 0, edgeTop = 0;
    for (let i = 0; i < points.count; i++) {
      if (Math.abs(points.getX(i)) < 0.006) centreTop = Math.max(centreTop, points.getY(i));
      if (Math.abs(points.getX(i)) > 0.06) edgeTop = Math.max(edgeTop, points.getY(i));
    }
    expect(centreTop - edgeTop).toBeGreaterThan(0.025);
    expect((arm.material as THREE.Material).name).toBe('PSF_Upholstery_v2');
    disposeGroup(model);
  });
  it('sculpts the broad cushion face instead of leaving a flat panel between corner arcs', () => {
    const model = createSofaStudy('brown'), cushion = model.getObjectByName('right-back-cushion') as THREE.Mesh;
    const p = cushion.geometry.getAttribute('position');
    const centre: number[] = [], edge: number[] = [];
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      if (Math.abs(y) < 0.006 && z > 0) {
        if (Math.abs(x) < 0.02) centre.push(z);
        if (Math.abs(x) > 0.22 && Math.abs(x) < 0.25) edge.push(z);
      }
    }
    expect(centre.length).toBeGreaterThan(0); expect(edge.length).toBeGreaterThan(0);
    expect(Math.max(...centre) - Math.max(...edge)).toBeGreaterThan(0.009);
    disposeGroup(model);
  });
});
