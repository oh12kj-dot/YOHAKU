import { defineConfig } from 'vite';
import { productSourcePlugin } from './apps/api/src/dev-product-plugin.ts';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  root: 'apps/web',
  plugins: [productSourcePlugin()],
  build: { outDir: '../../dist', emptyOutDir: true, rolldownOptions: { input: { editor: fileURLToPath(new URL('./apps/web/index.html', import.meta.url)), study: fileURLToPath(new URL('./apps/web/sofa-study.html', import.meta.url)) } } },
});
