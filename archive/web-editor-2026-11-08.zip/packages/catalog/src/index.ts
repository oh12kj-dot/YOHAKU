import type { Asset, Dimensions } from '../../contracts/src/index';

export const finishes = [
  { id: 'oak-natural', name: 'ナチュラルオーク', target: 'floor', color: '#c5a477', pattern: 'wood', roughness: 0.7 },
  { id: 'walnut', name: 'ウォールナット', target: 'floor', color: '#71513c', pattern: 'wood', roughness: 0.65 },
  { id: 'white-oak', name: 'ホワイトオーク', target: 'floor', color: '#ded3bb', pattern: 'wood', roughness: 0.8 },
  { id: 'stone', name: 'ライトストーン', target: 'floor', color: '#bbbcb5', pattern: 'tile', roughness: 0.85 },
  { id: 'ivory', name: 'アイボリー', target: 'wall', color: '#eee9dd', pattern: 'plaster', roughness: 0.95 },
  { id: 'sage', name: 'セージ', target: 'wall', color: '#9aa992', pattern: 'plaster', roughness: 0.95 },
  { id: 'clay', name: 'クレイ', target: 'wall', color: '#c29b86', pattern: 'plaster', roughness: 0.95 },
  { id: 'chalk', name: 'チョークホワイト', target: 'wall', color: '#f5f3eb', pattern: 'plaster', roughness: 0.95 },
  { id: 'slate', name: 'ブルーグレー', target: 'wall', color: '#778991', pattern: 'plaster', roughness: 0.95 },
] as const;
export type FinishId = typeof finishes[number]['id'];
export type ModelKind = 'sofa' | 'table' | 'chair';
export type CatalogAsset = Asset & { name: string; family: string; colorName: string; color: string; kind: ModelKind; origin: 'interaction-sample' };
const uuid = (n: number) => `10000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
function sample(n: number, family: string, name: string, colorName: string, color: string, kind: ModelKind, dimensions: Dimensions): CatalogAsset {
  return { assetVersionId: uuid(n), specVersionId: uuid(100 + n), dimensions, specPolicy: 'eligible', assetPolicy: 'eligible', granted: true, name, family, colorName, color, kind, origin: 'interaction-sample' };
}
// Hand-authored interaction samples. These are not replicas of any real product.
export const catalog: CatalogAsset[] = [
  sample(1, 'sofa', 'ラウンジソファ', 'サンド', '#c5b89d', 'sofa', { widthMm: 1800, depthMm: 850, heightMm: 800 }),
  sample(2, 'sofa', 'ラウンジソファ', 'モスグリーン', '#697c65', 'sofa', { widthMm: 1800, depthMm: 850, heightMm: 800 }),
  sample(3, 'sofa', 'ラウンジソファ', 'ブルーグレー', '#6a808b', 'sofa', { widthMm: 1800, depthMm: 850, heightMm: 800 }),
  sample(4, 'table', 'ラウンドテーブル', 'オーク', '#bd9260', 'table', { widthMm: 900, depthMm: 900, heightMm: 380 }),
  sample(5, 'table', 'ラウンドテーブル', 'ウォールナット', '#694b37', 'table', { widthMm: 900, depthMm: 900, heightMm: 380 }),
  sample(6, 'chair', 'アームチェア', 'アイボリー', '#d9d1bc', 'chair', { widthMm: 680, depthMm: 720, heightMm: 760 }),
  sample(7, 'chair', 'アームチェア', 'テラコッタ', '#ac7460', 'chair', { widthMm: 680, depthMm: 720, heightMm: 760 }),
];
export const catalogMap = new Map(catalog.map(a => [a.assetVersionId, a]));
export const surfaceTargets = ['FLOOR', 'NORTH', 'SOUTH', 'EAST', 'WEST'] as const;
export type SurfaceTarget = typeof surfaceTargets[number];
export const surfaceNames: Record<SurfaceTarget, string> = { FLOOR: '床', NORTH: '北の壁', SOUTH: '南の壁', EAST: '東の壁', WEST: '西の壁' };
export const defaultSurfaces = () => surfaceTargets.map(target => ({ target, materialId: target === 'FLOOR' ? 'oak-natural' as const : 'ivory' as const }));
