import { developmentLimits, dimensionsSchema, furnitureSchema, sceneCommandSchema, type Asset, type Furniture, type Room, type SceneDraft } from '../../contracts/src/index';
import { evaluateGeometry, normalizeYaw, replacementPosition, roundMm } from '../../geometry-kernel/src/index';
import { finishes } from '../../catalog/src/index';

export class DomainError extends Error {
  constructor(public code: 'SCHEMA_INVALID' | 'GEOMETRY_INVALID' | 'RESOURCE_NOT_FOUND' | 'ASSET_NOT_ADOPTABLE' | 'ASSET_CHANGED', message: string) { super(message); }
}
function normalizeRoom(room: Room): Room {
  const result: Room = { widthMm: roundMm(room.widthMm), depthMm: roundMm(room.depthMm), heightMm: roundMm(room.heightMm), columns: room.columns.map(c => ({ ...c, xMm: roundMm(c.xMm), zMm: roundMm(c.zMm), widthMm: roundMm(c.widthMm), depthMm: roundMm(c.depthMm), heightMm: roundMm(c.heightMm) })) };
  const ids = new Set<string>();
  if (Math.min(result.widthMm, result.depthMm, result.heightMm) <= 0) throw new DomainError('GEOMETRY_INVALID', '保存精度以上の内寸を入力してください。');
  for (const c of result.columns) {
    if (ids.has(c.columnId) || Math.min(c.widthMm, c.depthMm, c.heightMm) <= 0 || c.xMm < 0 || c.zMm < 0 || c.xMm + c.widthMm > result.widthMm || c.zMm + c.depthMm > result.depthMm || c.heightMm > result.heightMm) throw new DomainError('GEOMETRY_INVALID', '柱のID・寸法・室内範囲を確認してください。');
    ids.add(c.columnId);
  }
  return result;
}
export function applyCommand(scene: SceneDraft, input: unknown, assets: ReadonlyMap<string, Asset>): SceneDraft {
  const parsed = sceneCommandSchema.safeParse(input);
  if (!parsed.success) throw new DomainError('SCHEMA_INVALID', 'コマンドの形式・数値を確認してください。');
  const command = parsed.data;
  const next = structuredClone(scene);
  function asset(id: string, adoption = false): Asset {
    const result = assets.get(id);
    if (!result || !result.granted) throw new DomainError('RESOURCE_NOT_FOUND', '利用できるアセットがありません。');
    if (!dimensionsSchema.safeParse(result.dimensions).success) throw new DomainError('GEOMETRY_INVALID', 'アセットの寸法が不正です。');
    if (adoption && (result.specPolicy === 'blocked' || result.assetPolicy === 'blocked')) throw new DomainError('ASSET_NOT_ADOPTABLE', 'このアセットは新しく採用できません。');
    return result;
  }
  function item(id: string): Furniture {
    const result = next.furniture.find(f => f.instanceId === id);
    if (!result) throw new DomainError('RESOURCE_NOT_FOUND', '対象の配置がありません。');
    return result;
  }
  function add(f: Furniture) {
    if (next.furniture.some(i => i.instanceId === f.instanceId)) throw new DomainError('SCHEMA_INVALID', '配置IDが重複しています。');
    if (next.furniture.length >= developmentLimits.maxInstances) throw new DomainError('GEOMETRY_INVALID', '開発用の配置上限に達しました。');
    asset(f.assetVersionId, true);
    next.furniture.push(f);
  }
  switch (command.type) {
    case 'SetRoom': next.room = normalizeRoom(command.room); break;
    case 'SetSurface': {
      const finish = finishes.find(f => f.id === command.surface.materialId);
      if (!finish || finish.target !== (command.surface.target === 'FLOOR' ? 'floor' : 'wall')) throw new DomainError('SCHEMA_INVALID', '対象に対応する仕上げを選択してください。');
      const index = next.surfaces.findIndex(s => s.target === command.surface.target);
      if (index < 0) next.surfaces.push(command.surface);
      else next.surfaces[index] = command.surface;
      break;
    }
    case 'AddFurniture': add(command.furniture); break;
    case 'MoveFurniture': Object.assign(item(command.instanceId), { positionMm: command.positionMm, yawRad: command.yawRad }); break;
    case 'RemoveFurniture': item(command.instanceId); next.furniture = next.furniture.filter(f => f.instanceId !== command.instanceId); break;
    case 'DuplicateFurniture': add({ ...structuredClone(item(command.sourceInstanceId)), instanceId: command.instanceId, positionMm: command.positionMm }); break;
    case 'ReplaceFurniture': {
      const f = item(command.instanceId);
      if (f.assetVersionId !== command.expectedAssetVersionId) throw new DomainError('ASSET_CHANGED', '交換元のアセットが変更されています。');
      const old = asset(f.assetVersionId), target = asset(command.targetAssetVersionId, true);
      if (command.anchor === 'wall') f.positionMm = replacementPosition(f, old.dimensions, target.dimensions, next.room, command.wallId);
      f.assetVersionId = target.assetVersionId;
      break;
    }
  }
  for (const f of next.furniture) {
    f.positionMm = { x: roundMm(f.positionMm.x), y: 0, z: roundMm(f.positionMm.z) };
    f.yawRad = normalizeYaw(f.yawRad);
    if (!furnitureSchema.safeParse(f).success) throw new DomainError('GEOMETRY_INVALID', '計算後の配置が開発用の範囲を超えています。');
  }
  next.geometryWarnings = evaluateGeometry(next.room, next.furniture, id => asset(id).dimensions);
  return next;
}
