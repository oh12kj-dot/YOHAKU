import type { Asset, SceneDraft } from '../../contracts/src/index';
import { applyCommand } from './index';

export type LocalHistory = { present: SceneDraft; past: SceneDraft[]; future: SceneDraft[] };
export const createHistory = (present: SceneDraft): LocalHistory => ({ present, past: [], future: [] });
export function commitLocal(history: LocalHistory, command: unknown, assets: ReadonlyMap<string, Asset>): LocalHistory {
  const next = applyCommand(history.present, command, assets);
  if (JSON.stringify(next) === JSON.stringify(history.present)) return history;
  return { present: next, past: [...history.past.slice(-99), history.present], future: [] };
}
// Tab-only history; this does not issue server revisions or claim durable persistence.
export function stepLocal(history: LocalHistory, direction: 'undo' | 'redo', assets: ReadonlyMap<string, Asset>): LocalHistory {
  const source = direction === 'undo' ? history.past : history.future;
  const restored = source.at(-1); if (!restored) return history;
  const present = applyCommand(restored, { type: 'SetRoom', room: restored.room }, assets);
  return direction === 'undo'
    ? { present, past: source.slice(0, -1), future: [...history.future, history.present] }
    : { present, past: [...history.past, history.present], future: source.slice(0, -1) };
}
