import type { Dimensions, Furniture, PositionMm, Room, Wall, GeometryWarning } from '../../contracts/src/index';

export const roundMm = (value: number) => Math.round(value * 1000) / 1000;
export const toMeters = (mm: number) => mm / 1000;
export function normalizeYaw(rad: number): number {
  const turn = 2 * Math.PI;
  return ((rad % turn + Math.PI + turn) % turn) - Math.PI;
}
type Point = { x: number; z: number };
export function footprint(position: PositionMm, yaw: number, size: Dimensions): Point[] {
  const c = Math.cos(yaw), s = Math.sin(yaw);
  return [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([x, z]) => ({
    x: position.x + c * x * size.widthMm / 2 + s * z * size.depthMm / 2,
    z: position.z - s * x * size.widthMm / 2 + c * z * size.depthMm / 2,
  }));
}
// Open interior overlap: mere contact is not penetration. SAT over both rectangles.
export function overlaps(a: Point[], b: Point[]): boolean {
  for (const polygon of [a, b]) {
    for (let i = 0; i < 2; i++) {
      const p = polygon[i], q = polygon[i + 1];
      const axis = { x: -(q.z - p.z), z: q.x - p.x };
      const length = Math.hypot(axis.x, axis.z);
      const project = (v: Point) => (v.x * axis.x + v.z * axis.z) / length;
      const pa = a.map(project), pb = b.map(project);
      if (Math.min(Math.max(...pa), Math.max(...pb)) - Math.max(Math.min(...pa), Math.min(...pb)) <= 1e-7) return false;
    }
  }
  return true;
}
// Stable wall convention: NORTH z=0, SOUTH z=depth, WEST x=0, EAST x=width.
export function wallClearance(position: PositionMm, yaw: number, size: Dimensions, room: Room, wall: Wall): number {
  const points = footprint(position, yaw, size);
  switch (wall) {
    case 'NORTH': return Math.min(...points.map(p => p.z));
    case 'SOUTH': return room.depthMm - Math.max(...points.map(p => p.z));
    case 'WEST': return Math.min(...points.map(p => p.x));
    case 'EAST': return room.widthMm - Math.max(...points.map(p => p.x));
  }
}
export function replacementPosition(item: Furniture, oldSize: Dimensions, newSize: Dimensions, room: Room, wall: Wall): PositionMm {
  const delta = wallClearance(item.positionMm, item.yawRad, oldSize, room, wall) - wallClearance(item.positionMm, item.yawRad, newSize, room, wall);
  const n = { NORTH: [0, 1], SOUTH: [0, -1], WEST: [1, 0], EAST: [-1, 0] }[wall];
  return { x: roundMm(item.positionMm.x + n[0] * delta), y: 0, z: roundMm(item.positionMm.z + n[1] * delta) };
}
export function evaluateGeometry(room: Room, furniture: Furniture[], dimensions: (assetId: string) => Dimensions): GeometryWarning[] {
  const warnings: GeometryWarning[] = [];
  const add = (kind: GeometryWarning['kind'], targetIds: string[]) => warnings.push({ kind, targetIds, shape: 'coarse', geometryRuleVersion: 'coarse-obb-v1' });
  const shapes = furniture.map(f => footprint(f.positionMm, f.yawRad, dimensions(f.assetVersionId)));
  furniture.forEach((f, i) => {
    if (shapes[i].some(p => p.x < -1e-7 || p.z < -1e-7 || p.x > room.widthMm + 1e-7 || p.z > room.depthMm + 1e-7) || dimensions(f.assetVersionId).heightMm > room.heightMm) add('outside_room', [f.instanceId]);
    for (let j = 0; j < i; j++) if (overlaps(shapes[i], shapes[j])) add('collision_candidate', [furniture[j].instanceId, f.instanceId]);
    for (const col of room.columns) {
      const shape = footprint({ x: col.xMm + col.widthMm / 2, y: 0, z: col.zMm + col.depthMm / 2 }, 0, col);
      if (overlaps(shapes[i], shape)) add('column_collision_candidate', [f.instanceId, col.columnId]);
    }
  });
  return warnings;
}
