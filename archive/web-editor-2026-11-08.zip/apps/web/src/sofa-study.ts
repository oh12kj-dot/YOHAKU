import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { createSofaStudy, applyStudyFabric, studyColors, type StudyColor } from './sofa-study-model';
import { disposeGroup } from './models';
import source from './data/product-source.json';
import './sofa-study.css';

document.querySelector('#study')!.innerHTML = `
  <header><a class="study-brand" href="/">余白 <small>YOHAKU</small></a><span>PHOTO-REFERENCED MODEL STUDY <b>02</b></span><a class="back" href="/">部屋のエディターへ ↗</a></header>
  <main>
    <section class="stage"><div class="stage-title"><span class="eyebrow">CODE-AUTHORED · INTERACTIVE 3D</span><h1>写真を見て、かたちにする。</h1><p>商品写真に合わせ、クッション・肘・張地を作り直した3D試作品です。</p></div>
      <div id="model-canvas" aria-label="写真を参考に作成したソファの3D試作品" role="img"></div>
      <div class="prototype-tag">改修版 v2 · 品質未検証</div><div id="failure" role="alert" hidden></div>
      <div class="stage-controls"><button id="front">正面</button><button id="angle" aria-pressed="true">斜め</button><button id="detail">質感を拡大</button><button id="rear">背面</button><i></i><button id="auto" aria-pressed="false">自動回転</button></div>
      <p class="gesture">ドラッグで回転 · ホイールで拡大 · 右ドラッグで移動</p>
    </section>
    <aside><span class="eyebrow">PSF SOFA 2P — STUDY</span><h2>つくったのは、<br>このソファの近似モデル。</h2>
      <div class="reference"><img id="reference-image" alt="参考にしたブラウンの商品写真" src="${source.variants[0].imageUrl}"><span>参考にした商品写真 / FLYMEe</span></div>
      <p class="product-name">JOURNAL STANDARD FURNITURE<br>PSF SOFA 2P</p><p class="dimension">掲載外寸に合わせた設計値<br><strong>W 1500 × D 870 × H 820 mm</strong></p>
      <div class="color-buttons"><button id="brown" aria-pressed="true"><i style="background:#a46d43"></i>ブラウン</button><button id="blue-gray" aria-pressed="false"><i style="background:#556273"></i>ブルーグレー</button></div>
      <div class="caption"><h3>写真から読み取って形にした部分</h3><p>左右2枚の背クッション、一体型の座面、丸みのある肘、縫い目、黒い脚、前面の電源部。</p><h3>推定・未検証の部分</h3><p>底面の構造、個々のしわ、素材の正確な色と反射特性。寸法は掲載値を基準にしており、実測・別資料照合は未実施です。</p></div>
      <div class="boundary"><strong>写真からAIが自動復元したものではありません。</strong><p>形状は写真参照のコード製、張地は参照画像から作った生成テクスチャです。正式な家具アセットとしては未採用です。</p></div>
      <button id="download" class="download" disabled>この試作品をGLBで保存 ↓</button><p id="export-status" role="status"></p><a class="source-link" href="${source.sourceUrl}" target="_blank" rel="noreferrer">元の商品ページを見る ↗</a>
    </aside>
  </main><footer><span>3D形状：写真参照のコード製 · 張地：生成テクスチャ</span><span>PHOTO-REFERENCED STUDY · NOT VALIDATED</span></footer>`;

let color: StudyColor = 'brown', model: THREE.Group;
let loadRevision = 0, disposed = false;
let renderer: THREE.WebGLRenderer | undefined, frame = 0;
const host = document.querySelector<HTMLElement>('#model-canvas')!;
const failure = document.querySelector<HTMLElement>('#failure')!;
try {
  const canvas = document.createElement('canvas');
  if (!canvas.getContext('webgl2')) throw new Error('このブラウザーではWebGL2が利用できません。');
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15; host.append(canvas);
  const scene = new THREE.Scene(); scene.background = new THREE.Color('#eae7df');
  const camera = new THREE.PerspectiveCamera(33, 1, 0.02, 30), controls = new OrbitControls(camera, canvas);
  controls.target.set(0, 0.39, 0); controls.enableDamping = true; controls.minDistance = 1.1; controls.maxDistance = 6; controls.maxPolarAngle = Math.PI / 2 - 0.02; controls.autoRotateSpeed = 1.1;
  const pmrem = new THREE.PMREMGenerator(renderer), environmentScene = new RoomEnvironment(), environment = pmrem.fromScene(environmentScene, 0.04);
  scene.environment = environment.texture; scene.environmentIntensity = 0.65; pmrem.dispose(); environmentScene.dispose();
  scene.add(new THREE.HemisphereLight('#fff6e7', '#8c7c67', 1.6));
  const key = new THREE.DirectionalLight('#fff1dd', 3.2); key.position.set(-2, 4, 3); key.castShadow = true; key.shadow.mapSize.set(2048, 2048); key.shadow.camera.left = key.shadow.camera.bottom = -2.5; key.shadow.camera.right = key.shadow.camera.top = 2.5; key.shadow.camera.near = 0.1; key.shadow.camera.far = 12; key.shadow.camera.updateProjectionMatrix(); key.shadow.normalBias = 0.0008; key.shadow.bias = -0.00005; scene.add(key);
  const fill = new THREE.DirectionalLight('#e4edff', 1.4); fill.position.set(2, 2, -1); scene.add(fill);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: '#ded7ca', roughness: 0.92 })); ground.rotation.x = -Math.PI / 2; ground.position.y = -0.001; ground.receiveShadow = true; scene.add(ground);
  function disposeStudy(group: THREE.Group) {
    const maps = new Set<THREE.Texture>();
    group.traverse(o => { if (o instanceof THREE.Mesh && o.material instanceof THREE.MeshStandardMaterial) { if (o.material.map) maps.add(o.material.map); if (o.material.bumpMap) maps.add(o.material.bumpMap); if (o.material.normalMap) maps.add(o.material.normalMap); if (o.material.roughnessMap) maps.add(o.material.roughnessMap); } });
    disposeGroup(group); maps.forEach(map => map.dispose());
  }
  const showColor = async (next: StudyColor) => {
    const requestId = ++loadRevision, candidate = createSofaStudy(next);
    const download = document.querySelector<HTMLButtonElement>('#download')!, status = document.querySelector('#export-status')!;
    download.disabled = true; status.textContent = '張地の色・凹凸・反射マップを読み込み中…';
    try {
      await applyStudyFabric(candidate);
      if (requestId !== loadRevision || disposed) { disposeStudy(candidate); return; }
      if (model) { scene.remove(model); disposeStudy(model); }
      color = next; model = candidate; scene.add(model);
      document.querySelector('#brown')!.setAttribute('aria-pressed', String(color === 'brown'));
      document.querySelector('#blue-gray')!.setAttribute('aria-pressed', String(color === 'blue-gray'));
      const image = document.querySelector<HTMLImageElement>('#reference-image')!;
      image.src = source.variants[color === 'brown' ? 0 : 1].imageUrl!; image.alt = `参考にした${studyColors[color].name}の商品写真`;
      failure.hidden = true; status.textContent = ''; download.disabled = false;
    } catch (error) {
      disposeStudy(candidate);
      if (requestId === loadRevision && !disposed) {
        failure.hidden = false; failure.textContent = '張地のマップを読み込めませんでした。再読み込みしてください。';
        status.textContent = error instanceof Error ? error.message : '素材の読み込みに失敗しました。'; download.disabled = !model;
      }
    }
  };
  void showColor('brown');
  const setView = (view: 'front' | 'angle' | 'detail' | 'rear') => {
    controls.autoRotate = false; document.querySelector('#auto')!.setAttribute('aria-pressed', 'false');
    if (view === 'front') camera.position.set(0, 0.95, 2.8);
    else if (view === 'rear') camera.position.set(-1.8, 1.15, -2.4);
    else if (view === 'detail') camera.position.set(0.95, 0.77, 1.15);
    else camera.position.set(1.9, 1.3, 2.7);
    if (view === 'detail') controls.target.set(0.2, 0.5, 0.12);
    else controls.target.set(0, 0.4, 0);
    controls.update();
    for (const id of ['front', 'angle', 'detail', 'rear']) document.querySelector(`#${id}`)!.setAttribute('aria-pressed', String(view === id));
  };
  setView('angle');
  for (const view of ['front', 'angle', 'detail', 'rear'] as const) document.querySelector(`#${view}`)!.addEventListener('click', () => setView(view));
  for (const variant of ['brown', 'blue-gray'] as const) document.querySelector(`#${variant}`)!.addEventListener('click', () => { void showColor(variant); });
  document.querySelector('#auto')!.addEventListener('click', () => { controls.autoRotate = !controls.autoRotate; document.querySelector('#auto')!.setAttribute('aria-pressed', String(controls.autoRotate)); });
  document.querySelector('#download')!.addEventListener('click', async () => {
    const button = document.querySelector<HTMLButtonElement>('#download')!, status = document.querySelector('#export-status')!;
    const exportColor = color;
    const variants = ['brown', 'blue-gray'].map(id => document.getElementById(id) as HTMLButtonElement);
    variants.forEach(button => { button.disabled = true; });
    button.disabled = true; status.textContent = 'GLBを書き出しています…';
    try {
      const result = await new GLTFExporter().parseAsync(model, { binary: true, onlyVisible: true, maxTextureSize: 1024 });
      if (!(result instanceof ArrayBuffer)) throw new Error('GLBを生成できませんでした。');
      const blob = new Blob([result], { type: 'model/gltf-binary' }), url = URL.createObjectURL(blob), anchor = document.createElement('a');
      anchor.href = url; anchor.download = `psf-sofa-study-${exportColor}-v2.glb`; anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 10000);
      status.textContent = '未検証の試作モデルを書き出しました。';
    } catch (e) { status.textContent = e instanceof Error ? e.message : '書き出せませんでした。'; }
    finally { button.disabled = false; variants.forEach(button => { button.disabled = false; }); }
  });
  const observer = new ResizeObserver(() => { const { width, height } = host.getBoundingClientRect(); renderer!.setSize(width, height); camera.aspect = width / Math.max(height, 1); camera.updateProjectionMatrix(); }); observer.observe(host);
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); cancelAnimationFrame(frame); failure.hidden = false; failure.textContent = '3D描画の接続が失われました。再読み込みしてください。'; });
  const draw = () => { frame = requestAnimationFrame(draw); controls.update(); renderer!.render(scene, camera); }; draw();
  window.addEventListener('pagehide', () => { disposed = true; ++loadRevision; cancelAnimationFrame(frame); observer.disconnect(); controls.dispose(); if (model) disposeStudy(model); ground.geometry.dispose(); (ground.material as THREE.Material).dispose(); environment.dispose(); key.shadow.dispose(); renderer!.dispose(); }, { once: true });
} catch (e) {
  failure.hidden = false; failure.textContent = e instanceof Error ? e.message : '3D表示を開始できません。';
  document.querySelector<HTMLButtonElement>('#download')!.disabled = true;
}
