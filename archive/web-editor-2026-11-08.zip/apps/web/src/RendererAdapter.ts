import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { catalogMap, type SurfaceTarget } from '../../../packages/catalog/src/index';
import type { SceneCommand, SceneDraft, PositionMm, Furniture } from '../../../packages/contracts/src/index';
import { createFurnitureModel, disposeGroup } from './models';
import { createFinish } from './materials';

export type ViewMode = 'overview' | 'eye' | 'seated' | 'top';
export type Tool = 'select' | 'place' | 'paint' | 'camera';
export type RendererEvents = {
  onSelect: (id: string | null) => void;
  onSurface: (target: SurfaceTarget) => void;
  onCommand: (command: SceneCommand) => void;
  onPlace: (position: PositionMm) => void;
  onFailure: (message: string) => void;
};
export class RendererAdapter {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(45, 1, 0.03, 200);
  private controls: OrbitControls;
  private roomGroup = new THREE.Group();
  private furnitureGroup = new THREE.Group();
  private decoration = new THREE.Group();
  private ghost = new THREE.Group();
  private walls = new Map<SurfaceTarget, THREE.Mesh>();
  private observer: ResizeObserver;
  private frame = 0;
  private draft?: SceneDraft;
  private view: ViewMode = 'overview';
  private tool: Tool = 'select';
  private selected: string | null = null;
  private placing: string | null = null;
  private snap = true;
  private gridVisible = true;
  private drag?: { id: string; pointerId: number; startX: number; startY: number; offset: THREE.Vector3; position: PositionMm; moved: boolean };
  private raycaster = new THREE.Raycaster();
  private ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  private daylight = new THREE.DirectionalLight(0xfff0d9, 3.3);
  private ambient = new THREE.HemisphereLight(0xf3f4ff, 0xb4a18b, 2.3);
  constructor(host: HTMLElement, private events: RendererEvents) {
    const canvas = document.createElement('canvas');
    if (!canvas.getContext('webgl2')) throw new Error('WebGL2を利用できません。対応するPCブラウザーで開いてください。');
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.scene.background = new THREE.Color('#e8e9e3');
    this.scene.add(this.ambient, this.daylight, this.daylight.target, this.roomGroup, this.furnitureGroup, this.decoration, this.ghost);
    this.daylight.castShadow = true; this.daylight.shadow.mapSize.set(2048, 2048);
    this.daylight.shadow.bias = -0.00015; this.daylight.shadow.normalBias = 0.02;
    host.append(canvas);
    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.enableDamping = true; this.controls.dampingFactor = 0.12;
    this.controls.maxPolarAngle = Math.PI / 2 - 0.01;
    this.controls.minDistance = 0.1; this.controls.maxDistance = 100;
    this.controls.mouseButtons = { LEFT: undefined, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.ROTATE };
    this.controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };
    canvas.addEventListener('pointerdown', this.pointerDown);
    canvas.addEventListener('pointermove', this.pointerMove);
    canvas.addEventListener('pointerup', this.pointerUp);
    canvas.addEventListener('pointercancel', this.pointerCancel);
    canvas.addEventListener('pointerleave', this.pointerLeave);
    canvas.addEventListener('contextmenu', event => event.preventDefault());
    canvas.addEventListener('webglcontextlost', event => {
      event.preventDefault(); cancelAnimationFrame(this.frame);
      events.onFailure('3D描画が停止しました。編集内容は未保存です。再読み込み前に内容を控えてください。');
    });
    this.observer = new ResizeObserver(() => {
      const { width, height } = host.getBoundingClientRect();
      this.renderer.setSize(width, height); this.camera.aspect = width / Math.max(height, 1); this.camera.updateProjectionMatrix();
    });
    this.observer.observe(host);
    const render = () => {
      this.frame = requestAnimationFrame(render); this.controls.update();
      if (this.draft) {
        const { widthMm: w, depthMm: d } = this.draft.room;
        // Camera-facing cutaway changes visibility, never the stable surface IDs.
        this.walls.get('NORTH')!.visible = this.camera.position.z >= d / 2000;
        this.walls.get('SOUTH')!.visible = this.camera.position.z < d / 2000;
        this.walls.get('WEST')!.visible = this.camera.position.x >= w / 2000;
        this.walls.get('EAST')!.visible = this.camera.position.x < w / 2000;
        if (this.view === 'top') this.walls.forEach(wall => { wall.visible = false; });
      }
      this.renderer.render(this.scene, this.camera);
    };
    render();
  }
  setScene(draft: SceneDraft) {
    const roomChanged = !this.draft || JSON.stringify([this.draft.room, this.draft.surfaces]) !== JSON.stringify([draft.room, draft.surfaces]);
    const first = !this.draft; this.draft = draft;
    if (roomChanged) this.buildRoom();
    disposeGroup(this.furnitureGroup);
    for (const f of draft.furniture) {
      const asset = catalogMap.get(f.assetVersionId); if (!asset) continue;
      const model = createFurnitureModel(asset); model.userData.instanceId = f.instanceId;
      model.position.set(f.positionMm.x / 1000, 0, f.positionMm.z / 1000); model.rotation.y = f.yawRad;
      this.furnitureGroup.add(model);
    }
    this.updateSelection();
    if (first) this.setView('overview');
  }
  private buildRoom() {
    if (!this.draft) return;
    disposeGroup(this.roomGroup); this.walls.clear();
    const { room, surfaces } = this.draft, w = room.widthMm / 1000, d = room.depthMm / 1000, h = room.heightMm / 1000;
    const materialFor = (target: SurfaceTarget, width: number, depth: number) => createFinish(surfaces.find(s => s.target === target)?.materialId ?? (target === 'FLOOR' ? 'oak-natural' : 'ivory'), width, depth);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(w, d), materialFor('FLOOR', w, d));
    floor.rotation.x = -Math.PI / 2; floor.position.set(w / 2, 0, d / 2); floor.receiveShadow = true; floor.userData.surface = 'FLOOR'; this.roomGroup.add(floor);
    const base = new THREE.Mesh(new THREE.BoxGeometry(w + 0.08, 0.1, d + 0.08), new THREE.MeshStandardMaterial({ color: '#d0c4b0', roughness: 0.8 }));
    base.position.set(w / 2, -0.055, d / 2); this.roomGroup.add(base);
    const walls: [SurfaceTarget, number[], number[]][] = [
      ['NORTH', [w, h, 0.1], [w / 2, h / 2, -0.05]], ['SOUTH', [w, h, 0.1], [w / 2, h / 2, d + 0.05]],
      ['WEST', [0.1, h, d], [-0.05, h / 2, d / 2]], ['EAST', [0.1, h, d], [w + 0.05, h / 2, d / 2]],
    ];
    for (const [target, size, position] of walls) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(size[0], size[1], size[2]), materialFor(target, Math.max(size[0], size[2]), h));
      mesh.position.set(position[0], position[1], position[2]); mesh.userData.surface = target; mesh.receiveShadow = mesh.castShadow = true;
      this.roomGroup.add(mesh); this.walls.set(target, mesh);
      const trim = new THREE.Mesh(new THREE.BoxGeometry(size[0] === 0.1 ? 0.025 : w, 0.06, size[2] === 0.1 ? 0.025 : d), new THREE.MeshStandardMaterial({ color: '#f4f1e8', roughness: 0.7 }));
      trim.position.set(0, -h / 2 + 0.03, 0);
      if (target === 'WEST' || target === 'EAST') trim.position.x = target === 'WEST' ? 0.062 : -0.062;
      else trim.position.z = target === 'NORTH' ? 0.062 : -0.062;
      mesh.add(trim);
    }
    for (const c of room.columns) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(c.widthMm / 1000, c.heightMm / 1000, c.depthMm / 1000), new THREE.MeshStandardMaterial({ color: '#eee9dd', roughness: 0.9 }));
      mesh.position.set((c.xMm + c.widthMm / 2) / 1000, c.heightMm / 2000, (c.zMm + c.depthMm / 2) / 1000); mesh.castShadow = true; this.roomGroup.add(mesh);
    }
    const span = Math.max(w, d, h); const shadow = this.daylight.shadow.camera;
    shadow.left = shadow.bottom = -span; shadow.right = shadow.top = span; shadow.far = span * 6; shadow.updateProjectionMatrix();
    this.daylight.position.set(w * 0.6, span * 1.8, d * 1.4); this.daylight.target.position.set(w / 2, 0, d / 2);
    const points: THREE.Vector3[] = [];
    for (let x = 0; x <= w; x += 0.5) points.push(new THREE.Vector3(x, 0.002, 0), new THREE.Vector3(x, 0.002, d));
    for (let z = 0; z <= d; z += 0.5) points.push(new THREE.Vector3(0, 0.002, z), new THREE.Vector3(w, 0.002, z));
    const grid = new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(points), new THREE.LineBasicMaterial({ color: '#f5f7ec', opacity: 0.3, transparent: true }));
    grid.name = 'grid'; grid.visible = this.gridVisible; this.roomGroup.add(grid);
  }
  setGrid(value: boolean) { this.gridVisible = value; const grid = this.roomGroup.getObjectByName('grid'); if (grid) grid.visible = value; }
  setSnap(value: boolean) { this.snap = value; }
  setTool(tool: Tool, placing: string | null = null) {
    this.tool = tool; this.placing = placing; this.pointerCancel();
    this.controls.mouseButtons.LEFT = tool === 'camera' ? THREE.MOUSE.ROTATE : undefined;
    this.renderer.domElement.style.cursor = tool === 'place' || tool === 'paint' ? 'crosshair' : tool === 'camera' ? 'grab' : 'default';
    disposeGroup(this.ghost);
    if (placing) {
      const asset = catalogMap.get(placing);
      if (asset) {
        const model = createFurnitureModel(asset);
        model.traverse(o => { if (o instanceof THREE.Mesh) { const ms = Array.isArray(o.material) ? o.material : [o.material]; ms.forEach(m => { m.transparent = true; m.opacity = 0.55; m.depthWrite = false; }); o.castShadow = false; } });
        this.ghost.add(model); this.ghost.visible = false;
      }
    }
  }
  setSelection(id: string | null) { this.selected = id; this.updateSelection(); }
  private updateSelection() {
    disposeGroup(this.decoration); if (!this.draft || !this.selected) return;
    const f = this.draft.furniture.find(f => f.instanceId === this.selected), asset = f && catalogMap.get(f.assetVersionId); if (!f || !asset) return;
    const { widthMm: w, depthMm: d } = asset.dimensions;
    const geometry = new THREE.BoxGeometry(w / 1000 + 0.025, 0.01, d / 1000 + 0.025);
    const outline = new THREE.LineSegments(new THREE.EdgesGeometry(geometry), new THREE.LineBasicMaterial({ color: '#759563' })); geometry.dispose();
    outline.position.set(f.positionMm.x / 1000, 0.006, f.positionMm.z / 1000); outline.rotation.y = f.yawRad; this.decoration.add(outline);
    const halo = new THREE.Mesh(new THREE.RingGeometry(Math.max(w, d) / 2000 + 0.1, Math.max(w, d) / 2000 + 0.12, 64), new THREE.MeshBasicMaterial({ color: '#9ab581', transparent: true, opacity: 0.55, side: THREE.DoubleSide }));
    halo.rotation.x = -Math.PI / 2; halo.position.set(f.positionMm.x / 1000, 0.004, f.positionMm.z / 1000); this.decoration.add(halo);
  }
  private ray(event: PointerEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.raycaster.setFromCamera(new THREE.Vector2((event.clientX - rect.left) / rect.width * 2 - 1, -(event.clientY - rect.top) / rect.height * 2 + 1), this.camera);
  }
  private floorPoint(event: PointerEvent) { this.ray(event); return this.raycaster.ray.intersectPlane(this.ground, new THREE.Vector3()); }
  private position(point: THREE.Vector3): PositionMm {
    const step = this.snap ? 100 : 1;
    return { x: Math.round(point.x * 1000 / step) * step, y: 0, z: Math.round(point.z * 1000 / step) * step };
  }
  private pointerDown = (event: PointerEvent) => {
    if (event.button !== 0 || this.tool === 'camera' || !this.draft) return;
    if (this.tool === 'place' && this.placing) { const point = this.floorPoint(event); if (point) this.events.onPlace(this.position(point)); return; }
    this.ray(event);
    const hits = this.raycaster.intersectObjects(this.furnitureGroup.children, true);
    if (this.tool === 'select' && hits.length) {
      let model = hits[0].object; while (model.parent && !model.userData.instanceId) model = model.parent;
      const id = model.userData.instanceId as string, f = this.draft.furniture.find(f => f.instanceId === id);
      const point = this.floorPoint(event); if (!f || !point) return;
      this.events.onSelect(id); this.controls.enabled = false;
      this.drag = { id, pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, offset: new THREE.Vector3(f.positionMm.x / 1000, 0, f.positionMm.z / 1000).sub(point), position: f.positionMm, moved: false };
      this.renderer.domElement.setPointerCapture(event.pointerId); return;
    }
    if (this.tool === 'paint') {
      const surfaces = this.raycaster.intersectObjects(this.roomGroup.children.filter(o => o.visible), true);
      for (const hit of surfaces) { let object: THREE.Object3D | null = hit.object; while (object && !object.userData.surface) object = object.parent; if (object?.userData.surface) { this.events.onSurface(object.userData.surface as SurfaceTarget); break; } }
    } else this.events.onSelect(null);
  };
  private pointerMove = (event: PointerEvent) => {
    const point = this.floorPoint(event); if (!point) return;
    if (this.tool === 'place' && this.placing) { const p = this.position(point); this.ghost.position.set(p.x / 1000, 0, p.z / 1000); this.ghost.visible = true; }
    if (!this.drag || this.drag.pointerId !== event.pointerId) return;
    if (Math.hypot(event.clientX - this.drag.startX, event.clientY - this.drag.startY) < 3 && !this.drag.moved) return;
    this.drag.moved = true; this.drag.position = this.position(point.add(this.drag.offset));
    const model = this.furnitureGroup.children.find(o => o.userData.instanceId === this.drag!.id);
    if (model) model.position.set(this.drag.position.x / 1000, 0, this.drag.position.z / 1000);
    this.decoration.visible = false;
  };
  private pointerUp = (event: PointerEvent) => {
    const drag = this.drag; if (!drag || drag.pointerId !== event.pointerId) return;
    const f = this.draft?.furniture.find(f => f.instanceId === drag.id);
    this.drag = undefined; this.controls.enabled = true; this.decoration.visible = true;
    if (this.renderer.domElement.hasPointerCapture(event.pointerId)) this.renderer.domElement.releasePointerCapture(event.pointerId);
    if (drag.moved && f) this.events.onCommand({ type: 'MoveFurniture', instanceId: drag.id, positionMm: drag.position, yawRad: f.yawRad });
  };
  private pointerCancel = () => {
    const drag = this.drag; this.drag = undefined; this.controls.enabled = true; this.decoration.visible = true;
    if (drag && this.renderer.domElement.hasPointerCapture(drag.pointerId)) this.renderer.domElement.releasePointerCapture(drag.pointerId);
    if (this.draft && drag) this.setScene(this.draft);
  };
  private pointerLeave = () => { if (!this.drag) this.ghost.visible = false; };
  cancelInteraction() { this.pointerCancel(); this.ghost.visible = false; }
  setView(mode: ViewMode) {
    if (!this.draft) return; this.view = mode;
    const { room } = this.draft, w = room.widthMm / 1000, d = room.depthMm / 1000, span = Math.max(w, d, room.heightMm / 1000);
    if (mode === 'overview') { this.camera.position.set(w / 2 + span * 1.12, span * 1.05, d / 2 + span * 1.12); this.controls.target.set(w / 2, 0.4, d / 2); }
    else if (mode === 'top') { this.camera.position.set(w / 2, span * 1.9, d / 2 + 0.001); this.controls.target.set(w / 2, 0, d / 2); }
    else { const eye = Math.min(mode === 'eye' ? 1.6 : 1.1, room.heightMm / 1000 * 0.8); this.camera.position.set(w * 0.8, eye, d * 0.85); this.controls.target.set(w * 0.3, eye, d * 0.2); }
    this.controls.update();
  }
  resetView() { this.setView(this.view); }
  setNight(night: boolean) { this.daylight.intensity = night ? 0.8 : 3.3; this.ambient.intensity = night ? 0.7 : 2.3; this.daylight.color.set(night ? '#ffc781' : '#fff0d9'); this.renderer.toneMappingExposure = night ? 0.85 : 1; }
  dispose() {
    cancelAnimationFrame(this.frame); this.observer.disconnect(); this.controls.dispose();
    [this.roomGroup, this.furnitureGroup, this.decoration, this.ghost].forEach(disposeGroup);
    this.daylight.shadow.dispose(); this.renderer.dispose(); this.renderer.domElement.remove();
  }
}
export function moveCommand(f: Furniture, patch: Partial<{ x: number; z: number; yawRad: number }>): SceneCommand {
  return { type: 'MoveFurniture', instanceId: f.instanceId, positionMm: { x: patch.x ?? f.positionMm.x, y: 0, z: patch.z ?? f.positionMm.z }, yawRad: patch.yawRad ?? f.yawRad };
}
