import { StrictMode, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { catalog, catalogMap, defaultSurfaces, finishes, surfaceNames, surfaceTargets, type CatalogAsset, type SurfaceTarget } from '../../../packages/catalog/src/index';
import type { SceneCommand, SceneDraft } from '../../../packages/contracts/src/index';
import { createHistory, commitLocal, stepLocal, type LocalHistory } from '../../../packages/scene-domain/src/history';
import type { ProductSource } from '../../../workers/import/src/product-source';
import sourceSnapshot from './data/product-source.json';
import { RendererAdapter, moveCommand, type RendererEvents, type Tool, type ViewMode } from './RendererAdapter';
import { RoomPlan } from './RoomPlan';
import './style.css';

const initial: SceneDraft = { schemaVersion: 1, layoutId: crypto.randomUUID(), room: { widthMm: 4000, depthMm: 3500, heightMm: 2400, columns: [] }, surfaces: defaultSurfaces(), furniture: [], geometryWarnings: [] };
type Tab = 'room' | 'finishes' | 'furniture' | 'import';
function Thumbnail({ asset }: { asset: CatalogAsset }) {
  return <svg viewBox="0 0 190 130" aria-hidden="true" className="furniture-thumbnail">
    <ellipse cx="96" cy="104" rx="65" ry="9" fill="#30402b" opacity=".07" />
    {asset.kind === 'table' ? <g><path d="M65 69L59 103M126 69L134 100M94 70L95 110" stroke="#78543a" strokeWidth="7" /><ellipse cx="96" cy="68" rx="63" ry="23" fill={asset.color} /><ellipse cx="96" cy="63" rx="63" ry="23" fill={asset.color} stroke="#ffffff50" /></g> : <g>
      <path d="M45 89L42 105M146 89L149 105" stroke="#78543a" strokeWidth="6" />
      <rect x={asset.kind === 'chair' ? 55 : 29} y="36" width={asset.kind === 'chair' ? 80 : 132} height="52" rx="13" fill={asset.color} />
      <rect x={asset.kind === 'chair' ? 52 : 25} y="70" width={asset.kind === 'chair' ? 86 : 140} height="28" rx="8" fill={asset.color} stroke="#4b503225" />
      <rect x={asset.kind === 'chair' ? 47 : 20} y="54" width="19" height="39" rx="7" fill={asset.color} stroke="#ffffff40" />
      <rect x={asset.kind === 'chair' ? 124 : 151} y="54" width="19" height="39" rx="7" fill={asset.color} stroke="#ffffff40" />
      <path d={asset.kind === 'chair' ? 'M68 75H124' : 'M40 75H151M96 76V94'} stroke="#4b503225" fill="none" />
    </g>}
  </svg>;
}
function App() {
  const [history, setHistory] = useState<LocalHistory>(() => createHistory(initial));
  const historyRef = useRef(history); const scene = history.present;
  const [tab, setTab] = useState<Tab>('furniture');
  const [tool, setTool] = useState<Tool>('select');
  const [selected, setSelected] = useState<string | null>(null);
  const [placing, setPlacing] = useState<string | null>(null);
  const [target, setTarget] = useState<SurfaceTarget>('FLOOR');
  const [plan, setPlan] = useState(false);
  const [night, setNight] = useState(false), [grid, setGrid] = useState(true), [snap, setSnap] = useState(true);
  const [view, setView] = useState<ViewMode>('overview');
  const [message, setMessage] = useState('左の家具を選び、床をクリックして配置できます。');
  const [error, setError] = useState(''), [renderError, setRenderError] = useState('');
  const [dirty, setDirty] = useState(false), [measured, setMeasured] = useState(false);
  const [roomInput, setRoomInput] = useState({ widthMm: '4000', depthMm: '3500', heightMm: '2400' });
  const [category, setCategory] = useState('all');
  const [product, setProduct] = useState<ProductSource>(sourceSnapshot as ProductSource);
  const [productUrl, setProductUrl] = useState(sourceSnapshot.sourceUrl);
  const [productVariant, setProductVariant] = useState('27425');
  const [loading, setLoading] = useState(false);
  const [sourceError, setSourceError] = useState('');
  const host = useRef<HTMLDivElement>(null), adapter = useRef<RendererAdapter | null>(null);
  const selectedItem = scene.furniture.find(f => f.instanceId === selected), selectedAsset = selectedItem && catalogMap.get(selectedItem.assetVersionId);
  const placingAsset = placing && catalogMap.get(placing);
  const updateHistory = (next: LocalHistory) => { historyRef.current = next; setHistory(next); setDirty(true); setError(''); };
  const commit = (command: SceneCommand) => {
    try { const next = commitLocal(historyRef.current, command, catalogMap); if (next !== historyRef.current) updateHistory(next); return true; }
    catch (e) { setError(e instanceof Error ? e.message : '操作できませんでした。'); adapter.current?.setScene(historyRef.current.present); return false; }
  };
  const cancel = () => { setPlacing(null); setTool('select'); adapter.current?.cancelInteraction(); setMessage('操作を中止しました。'); };
  const historyStep = (direction: 'undo' | 'redo') => {
    cancel();
    try { const next = stepLocal(historyRef.current, direction, catalogMap); if (next !== historyRef.current) { updateHistory(next); setMessage(direction === 'undo' ? 'ひとつ前に戻しました。' : '操作をやり直しました。'); } }
    catch (e) { setError(e instanceof Error ? e.message : '履歴を復元できません。'); }
  };
  const remove = () => { if (selectedItem) { commit({ type: 'RemoveFurniture', instanceId: selectedItem.instanceId }); setSelected(null); setMessage('家具を削除しました。元に戻すこともできます。'); } };
  const rotate = (degrees: number) => { if (selectedItem) commit(moveCommand(selectedItem, { yawRad: selectedItem.yawRad + degrees * Math.PI / 180 })); };
  const events = useRef<RendererEvents>(null!);
  events.current = {
    onSelect: id => { setSelected(id); if (id) { setTab('furniture'); setMessage('ドラッグで移動 · Rで45°回転 · Deleteで削除'); } },
    onSurface: surface => { setTarget(surface); setTab('finishes'); setSelected(null); setMessage(`${surfaceNames[surface]}を選択しました。素材を選んで仕上げを変更できます。`); },
    onCommand: command => { commit(command); },
    onPlace: position => {
      if (!placing) return; const instanceId = crypto.randomUUID();
      if (commit({ type: 'AddFurniture', furniture: { instanceId, assetVersionId: placing, positionMm: position, yawRad: 0 } })) { setSelected(instanceId); setPlacing(null); setTool('select'); setMessage('家具を配置しました。つかんで移動できます。'); }
    },
    onFailure: setRenderError,
  };
  useEffect(() => {
    try { adapter.current = new RendererAdapter(host.current!, { onSelect: id => events.current.onSelect(id), onSurface: surface => events.current.onSurface(surface), onCommand: command => events.current.onCommand(command), onPlace: position => events.current.onPlace(position), onFailure: value => events.current.onFailure(value) }); adapter.current.setScene(initial); }
    catch (e) { setRenderError(e instanceof Error ? e.message : '3D表示を開始できません。'); }
    return () => { adapter.current?.dispose(); adapter.current = null; };
  }, []);
  useEffect(() => { adapter.current?.setScene(scene); setRoomInput({ widthMm: String(scene.room.widthMm), depthMm: String(scene.room.depthMm), heightMm: String(scene.room.heightMm) }); if (selected && !scene.furniture.some(f => f.instanceId === selected)) setSelected(null); }, [scene]);
  useEffect(() => { adapter.current?.setSelection(selected); }, [selected, scene]);
  useEffect(() => { adapter.current?.setTool(tool, placing); }, [tool, placing]);
  useEffect(() => { adapter.current?.setView(view); }, [view]);
  useEffect(() => { adapter.current?.setNight(night); }, [night]);
  useEffect(() => { adapter.current?.setGrid(grid); }, [grid]);
  useEffect(() => { adapter.current?.setSnap(snap); }, [snap]);
  const keyboard = useRef<(event: KeyboardEvent) => void>(null!);
  keyboard.current = event => {
    if ((event.target as HTMLElement).closest('input,textarea,select,[contenteditable=true]')) return;
    if (event.key === 'Escape') { cancel(); setPlan(false); }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); historyStep(event.shiftKey ? 'redo' : 'undo'); }
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'y') { event.preventDefault(); historyStep('redo'); }
    if (event.key.toLowerCase() === 'r' && !event.ctrlKey && !event.metaKey) rotate(45);
    if (event.key === 'Delete' || event.key === 'Backspace') { event.preventDefault(); remove(); }
  };
  useEffect(() => {
    const key = (event: KeyboardEvent) => keyboard.current(event), unload = (event: BeforeUnloadEvent) => { if (historyRef.current.past.length || historyRef.current.future.length) event.preventDefault(); };
    window.addEventListener('keydown', key); window.addEventListener('beforeunload', unload);
    return () => { window.removeEventListener('keydown', key); window.removeEventListener('beforeunload', unload); };
  }, []);
  function chooseTab(value: Tab) { cancel(); setTab(value); setPlan(false); setTool(value === 'finishes' ? 'paint' : 'select'); }
  const chooseFurniture = (asset: CatalogAsset) => { setPlan(false); setPlacing(asset.assetVersionId); setSelected(null); setTool('place'); setMessage(`${asset.name}を配置：床をクリック / Escで中止`); };
  const currentMaterial = scene.surfaces.find(s => s.target === target)?.materialId;
  const sourceVariant = product.variants.find(v => v.id === productVariant) ?? product.variants[0];
  return <div className="app">
    <header><a className="brand" href="/">余白<span>YOHAKU</span></a><div className="project-title"><strong>わたしの部屋</strong><span>BUILD YOUR EVERYDAY</span></div><div className="header-actions"><span className="save-state">● このタブのみ・未保存</span><span className="badge">ローカルプレビュー</span></div></header>
    <div className="workspace-toolbar"><div className="tool-group"><button aria-label="元に戻す" title="元に戻す Ctrl+Z" disabled={!history.past.length} onClick={() => historyStep('undo')}>↶</button><button aria-label="やり直す" title="やり直す Ctrl+Shift+Z" disabled={!history.future.length} onClick={() => historyStep('redo')}>↷</button><i /><button aria-pressed={tool === 'select' && !plan} onClick={() => { cancel(); setPlan(false); }}><span>↖</span> 選択</button><button aria-label="視点" aria-pressed={tool === 'camera'} onClick={() => { cancel(); setPlan(false); setTool('camera'); }}><span>✥</span> 視点</button></div><div className="tool-group"><button aria-pressed={snap} onClick={() => setSnap(!snap)}>⌗ スナップ {snap ? 'ON' : 'OFF'}</button><button aria-pressed={grid} onClick={() => setGrid(!grid)}>▦ グリッド</button><i /><span className="toolbar-size">{scene.room.widthMm.toLocaleString()} × {scene.room.depthMm.toLocaleString()} mm</span></div></div>
    <main>
      <aside className="left-panel"><nav className="panel-tabs" aria-label="編集カテゴリ">{([['room', '⌑', '部屋'], ['finishes', '▧', '壁・床'], ['furniture', '▱', '家具'], ['import', '↗', '商品URL']] as const).map(([key, icon, label]) => <button key={key} aria-pressed={tab === key} onClick={() => chooseTab(key)}><span>{icon}</span>{label}</button>)}</nav>
        <div className="panel-content">
        {tab === 'room' && <><p className="eyebrow">CREATE YOUR ROOM</p><h1>部屋を、かたちに。</h1><p className="intro">ドラッグで広さを決めて、<br />実測値でぴったり調整。</p><button className="primary" onClick={() => { cancel(); setPlan(true); }}>＋ 平面で部屋を描く</button><section><div className="section-heading"><h2>部屋の内寸</h2><span className="chip">{measured ? '入力値を反映' : '仮のサイズ'}</span></div><form onSubmit={event => { event.preventDefault(); if (commit({ type: 'SetRoom', room: { ...scene.room, widthMm: Number(roomInput.widthMm), depthMm: Number(roomInput.depthMm), heightMm: Number(roomInput.heightMm) } })) { setMeasured(true); setMessage('部屋の内寸を変更しました。家具のサイズ・位置は維持されます。'); } }}>
          {([['widthMm', '幅'], ['depthMm', '奥行き'], ['heightMm', '天井高']] as const).map(([key, label]) => <label key={key} className="dimension-label">{label}<div className="input-wrap"><input aria-label={label} type="number" required min="0.001" max="30000" step="0.001" value={roomInput[key]} onChange={event => setRoomInput({ ...roomInput, [key]: event.target.value })} /><span>mm</span></div></label>)}<button aria-label="部屋に反映する" className="secondary" type="submit">部屋に反映する ↗</button></form><p className="hint">壁の内側を実測してください。<br />ドラッグで作った値は実測値ではありません。</p></section><div className="tip-card"><span>小さなヒント</span><p>部屋を小さくしても家具はそのまま。<br />はみ出した家具は警告でお知らせします。</p></div></>}
        {tab === 'finishes' && <><p className="eyebrow">MATERIAL & COLOR</p><h1>空間に、表情を。</h1><p className="intro">壁や床をクリックして選択。<br />好みの仕上げを選びましょう。</p><div className="surface-targets">{surfaceTargets.map(t => <button key={t} aria-pressed={target === t} onClick={() => setTarget(t)}>{surfaceNames[t]}</button>)}</div><section><div className="section-heading"><h2>{surfaceNames[target]}の仕上げ</h2><span className="chip">{target === 'FLOOR' ? '4種類' : '5種類'}</span></div><div className="finish-grid">{finishes.filter(f => f.target === (target === 'FLOOR' ? 'floor' : 'wall')).map(f => <button key={f.id} className="finish-card" aria-label={f.name} aria-pressed={currentMaterial === f.id} onClick={() => { commit({ type: 'SetSurface', surface: { target, materialId: f.id } }); setMessage(`${surfaceNames[target]}を${f.name}に変更しました。`); }}><span className={`finish-swatch ${f.pattern}`} style={{ backgroundColor: f.color }}>{currentMaterial === f.id && <b>✓</b>}</span><span>{f.name}</span></button>)}</div></section><p className="hint">壁の名前は北=z0、南=奥行、<br />西=x0、東=幅です。隠れた壁も選べます。</p></>}
        {tab === 'furniture' && <><p className="eyebrow">FURNITURE COLLECTION</p><h1>お気に入りを、置こう。</h1><p className="intro">家具を選んで、床をクリック。<br />置いたあとは、つかんで移動。</p><p className="catalog-note">操作サンプル 3種類 · 実商品モデルは未生成</p><div className="category-tabs">{[['all', 'すべて'], ['sofa', 'ソファ'], ['table', 'テーブル'], ['chair', 'チェア']].map(([key, label]) => <button key={key} aria-pressed={category === key} onClick={() => setCategory(key)}>{label}</button>)}</div><div className="furniture-catalog">{catalog.filter(a => (category === 'all' || a.family === category) && catalog.find(item => item.family === a.family)?.assetVersionId === a.assetVersionId).map(asset => <button key={asset.assetVersionId} className={`furniture-card ${placingAsset && placingAsset.family === asset.family ? 'chosen' : ''}`} aria-label={`${asset.name}を配置`} onClick={() => chooseFurniture(asset)}><Thumbnail asset={asset} /><div><strong>{asset.name}</strong><span>{asset.dimensions.widthMm} × {asset.dimensions.depthMm} mm</span></div><b>＋</b></button>)}</div><div className="tip-card"><span>操作サンプルについて</span><p>この3点は操作確認用の独自モデルです。実商品の写真と色候補は「商品URL」で確認できます。3D生成は接続待ちです。</p><button className="text-button" onClick={() => chooseTab('import')}>商品写真から取り込む ↗</button></div></>}
        {tab === 'import' && <><p className="eyebrow">PHOTO TO FURNITURE</p><h1>写真から、わが家へ。</h1><p className="intro">商品ページの画像・寸法・色を取得。<br />写真から3D化するための素材を集めます。</p><form onSubmit={async event => { event.preventDefault(); setLoading(true); setSourceError(''); try { const response = await fetch(`/api/development/product-source?url=${encodeURIComponent(productUrl)}`); if (!response.headers.get('content-type')?.includes('application/json')) throw new Error('商品取得APIは開発サーバーで利用できます。'); const body = await response.json(); if (!response.ok) throw new Error(body.error); setProduct(body.data); setProductVariant(body.data.variants[0].id); } catch (e) { setSourceError(e instanceof Error ? e.message : '取得できませんでした。'); } finally { setLoading(false); } }}><label className="url-label">FLYMEeの商品URL<input type="url" required value={productUrl} onChange={event => setProductUrl(event.target.value)} /></label><button className="secondary" disabled={loading}>{loading ? 'ページを調査中…' : '商品情報を取得 ↗'}</button></form>{sourceError && <p role="alert" className="error">{sourceError}</p>}<article className="product-source"><p className="source-stage">○ 自動復元モデル未生成</p><div className="product-photo">{sourceVariant?.imageUrl && <img src={sourceVariant.imageUrl} alt={`${product.name} ${sourceVariant.name}の商品写真`} />}</div><span className="eyebrow">取得した商品</span><h2>{product.name}</h2><div className="source-variants">{product.variants.map(variant => <button key={variant.id} aria-pressed={sourceVariant?.id === variant.id} onClick={() => setProductVariant(variant.id)}>{variant.name}</button>)}</div><p className="source-size">W {product.dimensions.widthMm} × D {product.dimensions.depthMm} × H {product.dimensions.heightMm} mm</p><p className="hint">掲載値を取得 · 追加資料との照合前<br />{product.alternateConfiguration}</p><a href={product.sourceUrl} target="_blank" rel="noreferrer" className="text-link">商品ページ・出典を確認 ↗</a>{product.productId === '106294' && <p><a className="text-link" href="/sofa-study.html" target="_blank" rel="noreferrer">写真を参考にした3D試作品を見る ↗</a></p>}<div className="generation-status"><span>3D生成先の接続が必要です</span><p>写真からの3D生成にはfalなどの生成先への接続が必要です。接続後にこの写真を生成へ送れます。</p><button disabled>3D生成先の接続待ち</button></div></article></>}
        </div>
      </aside>
      <div className="viewport">
        <div ref={host} className="canvas-host" aria-label="部屋の3Dエディター" role="img" />
        <div className="viewport-top"><span><i /> 配置案 01 <small>／ {scene.furniture.length ? `${scene.furniture.length}点の家具` : '空の部屋'}</small></span><button className="light-button" onClick={() => adapter.current?.resetView()}>視点を戻す ↺</button></div>
        {renderError && <div className="render-error" role="alert"><h2>3D表示を利用できません</h2><p>{renderError}</p></div>}
        {plan && <RoomPlan room={scene.room} snap={snap} onCommit={room => { if (commit({ type: 'SetRoom', room })) setMeasured(true); }} onClose={() => { setPlan(false); adapter.current?.resetView(); }} />}
        {!plan && <><div className="floating-tools"><button title="部屋を描く" aria-label="部屋を描く" onClick={() => { chooseTab('room'); setPlan(true); }}>⌑</button><button title="壁・床を選ぶ" aria-label="壁・床を選ぶ" aria-pressed={tool === 'paint'} onClick={() => chooseTab('finishes')}>▧</button><button title="家具を選ぶ" aria-label="家具を選ぶ" onClick={() => chooseTab('furniture')}>▱</button></div>{placingAsset && <div className="placing-banner"><span>＋ {placingAsset.name}を配置中</span><button onClick={cancel}>中止 Esc</button></div>}<div className="view-toolbar"><div>{([['overview', '俯瞰'], ['top', '真上'], ['eye', '立った目線'], ['seated', '座った目線']] as const).map(([key, label]) => <button key={key} aria-pressed={view === key} onClick={() => setView(key)}>{label}</button>)}</div><i /><button aria-pressed={night} onClick={() => setNight(!night)}>{night ? '☾ 夜' : '☀ 昼'}</button></div></>}
        <div className="viewport-status"><p role="status">{message}</p><span>{error ? <b role="alert">{error}</b> : '右ドラッグ：視点回転 · Shift＋右ドラッグ：移動 · ホイール：拡大'}</span></div>
      </div>
      <aside className="right-panel"><div className="panel-content">
        {selectedItem && selectedAsset ? <><p className="eyebrow">SELECTED FURNITURE</p><div className="selected-preview"><Thumbnail asset={selectedAsset} /></div><h2 className="inspector-title">{selectedAsset.name}</h2><span className="chip">操作サンプル · {selectedAsset.colorName}</span><p className="source-size">W {selectedAsset.dimensions.widthMm} × D {selectedAsset.dimensions.depthMm} × H {selectedAsset.dimensions.heightMm} mm</p><section><h3>カラー</h3><div className="color-options">{catalog.filter(a => a.family === selectedAsset.family).map(asset => <button key={asset.assetVersionId} aria-label={`色を${asset.colorName}に変更`} title={asset.colorName} aria-pressed={selectedItem.assetVersionId === asset.assetVersionId} style={{ backgroundColor: asset.color }} onClick={() => commit({ type: 'ReplaceFurniture', instanceId: selectedItem.instanceId, expectedAssetVersionId: selectedItem.assetVersionId, targetAssetVersionId: asset.assetVersionId, anchor: 'center' })}>{selectedItem.assetVersionId === asset.assetVersionId && '✓'}</button>)}</div></section><section><h3>位置・向き</h3><div className="position-inputs">{([['x', 'X位置', selectedItem.positionMm.x], ['z', 'Z位置', selectedItem.positionMm.z], ['yawRad', '回転角', Math.round(selectedItem.yawRad * 180 / Math.PI * 100) / 100]] as const).map(([key, label, value]) => <label key={key}>{label}<div><input key={`${selectedItem.instanceId}-${key}-${value}`} type="number" aria-label={label} defaultValue={value} min={key === 'yawRad' ? undefined : -100000} max={key === 'yawRad' ? undefined : 100000} step={key === 'yawRad' ? 1 : 100} onBlur={event => { if (event.target.value.trim() && Number.isFinite(event.target.valueAsNumber)) commit(moveCommand(selectedItem, { [key]: key === 'yawRad' ? event.target.valueAsNumber * Math.PI / 180 : event.target.valueAsNumber })); }} onKeyDown={event => { if (event.key === 'Enter') event.currentTarget.blur(); }} /><span>{key === 'yawRad' ? '°' : 'mm'}</span></div></label>)}</div><div className="inspector-buttons"><button onClick={() => rotate(-45)}>↶ −45°</button><button onClick={() => rotate(45)}>↷ ＋45°</button></div></section><section><div className="inspector-buttons"><button onClick={() => { const instanceId = crypto.randomUUID(); if (commit({ type: 'DuplicateFurniture', sourceInstanceId: selectedItem.instanceId, instanceId, positionMm: { x: selectedItem.positionMm.x + 200, y: 0, z: selectedItem.positionMm.z + 200 } })) setSelected(instanceId); }}>複製</button><button className="danger" onClick={remove}>削除</button></div><p className="hint">Rで45°回転 · Deleteで削除<br />Ctrl+Zで元に戻す</p></section></> : <><p className="eyebrow">YOUR SPACE</p><h2 className="inspector-title">心地よい暮らしを、ここから。</h2><div className="area"><strong>{(scene.room.widthMm * scene.room.depthMm / 1e6).toFixed(2)}</strong><span>m²</span></div><p className="hint">入力した内寸から算出した床面積</p><hr /><div className="how-to"><span>01</span><div><b>部屋をつくる</b><p>ドラッグで広さを決める。</p></div></div><div className="how-to"><span>02</span><div><b>素材を選ぶ</b><p>壁と床に、お気に入りの表情を。</p></div></div><div className="how-to"><span>03</span><div><b>家具を置く</b><p>選んで、置いて、動かして。</p></div></div><p className="hint">壁は視点に合わせて一時非表示になります。壁・床パネルから全4壁を選べます。</p></>}
        {scene.geometryWarnings.length > 0 && <section className="warnings" role="status"><h3>配置の確認 · {scene.geometryWarnings.length}件</h3>{scene.geometryWarnings.map((warning, i) => <button key={i} onClick={() => { setSelected(warning.targetIds[0]); setTool('select'); }}>{warning.kind === 'outside_room' ? '⚠ 部屋からはみ出しています' : '⚠ 外形の衝突候補があります'}</button>)}<p className="hint">外形箱による概算です。詳細な形状の干渉判定ではありません。</p></section>}
        {scene.furniture.length > 0 && <section className="placed-list"><h3>配置した家具 <span>{scene.furniture.length}</span></h3>{scene.furniture.map((f, i) => <button key={f.instanceId} aria-pressed={selected === f.instanceId} onClick={() => { cancel(); setSelected(f.instanceId); setPlan(false); }}>{catalogMap.get(f.assetVersionId)?.name} <small>{String(i + 1).padStart(2, '0')}</small></button>)}</section>}
        <div className="local-note"><span>◌ ローカル編集</span><p>{dirty ? '編集内容はこのタブ内だけにあります。' : 'これからつくる部屋は、このタブ内の下書きです。'}再読み込みで失われます。写実品質・実機性能は未検証です。</p></div>
      </div></aside>
    </main><footer><span>余白をつくる。暮らしが変わる。</span><span>BUILD MODE <i>●</i> {placing ? '家具を配置中' : plan ? '部屋を作成中' : '自由に編集'}</span><span>LOCAL DEVELOPMENT · 0.2</span></footer>
  </div>;
}
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
