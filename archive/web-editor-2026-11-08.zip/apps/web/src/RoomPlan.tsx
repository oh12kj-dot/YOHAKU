import { useEffect, useRef, useState } from 'react';
import type { Room } from '../../../packages/contracts/src/index';

type Drag = { start: { x: number; y: number }; kind: 'draw' | 'width' | 'depth' | 'both'; width: number; depth: number; x: number; y: number };
export function RoomPlan({ room, snap, onCommit, onClose }: { room: Room; snap: boolean; onCommit: (room: Room) => void; onClose: () => void }) {
  const svg = useRef<SVGSVGElement>(null);
  const active = useRef<Drag | null>(null);
  const [preview, setPreview] = useState<Drag | null>(null);
  const [message, setMessage] = useState('対角の2点をドラッグ。角のハンドルでサイズを調整できます。');
  const span = Math.max(6500, room.widthMm + 2000, room.depthMm + 2000);
  const point = (event: React.PointerEvent) => {
    const node = svg.current!, ctm = node.getScreenCTM(); if (!ctm) return { x: 0, y: 0 };
    const p = new DOMPoint(event.clientX, event.clientY).matrixTransform(ctm.inverse());
    const step = snap ? 100 : 1; return { x: Math.round(p.x / step) * step, y: Math.round(p.y / step) * step };
  };
  const start = (event: React.PointerEvent, kind: Drag['kind']) => {
    if (event.button !== 0) return; event.stopPropagation();
    const p = point(event);
    active.current = { start: p, kind, width: kind === 'draw' ? 0 : room.widthMm, depth: kind === 'draw' ? 0 : room.depthMm, x: 0, y: 0 }; setPreview(active.current);
    svg.current!.setPointerCapture(event.pointerId);
  };
  const cancel = () => { active.current = null; setPreview(null); };
  useEffect(() => { active.current = null; setPreview(null); }, [room]);
  const w = preview?.width ?? room.widthMm, d = preview?.depth ?? room.depthMm;
  return <div className="plan-editor">
    <div className="plan-heading"><div><span className="eyebrow">ROOM BUILDER</span><h2>ドラッグして、部屋をつくる</h2></div><button className="light-button" onClick={onClose}>3Dに戻る ↗</button></div>
    <svg ref={svg} className="plan-svg" aria-label="部屋を描く平面エディター" viewBox={`-700 -700 ${span} ${span}`} onPointerDown={event => start(event, 'draw')} onPointerMove={event => {
      const drag = active.current; if (!drag) return; const p = point(event);
      const next = { ...drag };
      if (drag.kind === 'draw') { next.width = Math.abs(p.x - drag.start.x); next.depth = Math.abs(p.y - drag.start.y); next.x = Math.min(p.x, drag.start.x); next.y = Math.min(p.y, drag.start.y); }
      else { if (drag.kind !== 'depth') next.width = Math.max(0, p.x); if (drag.kind !== 'width') next.depth = Math.max(0, p.y); }
      active.current = next; setPreview(next);
    }} onPointerUp={event => {
      const drag = active.current; cancel();
      if (svg.current!.hasPointerCapture(event.pointerId)) svg.current!.releasePointerCapture(event.pointerId);
      if (!drag) return;
      if (drag.width < 100 || drag.depth < 100) { setMessage('100mm以上ドラッグしてください。実測値は数値欄で補正できます。'); return; }
      onCommit({ ...room, widthMm: drag.width, depthMm: drag.depth }); setMessage('部屋のサイズを変更しました。入力値は実測値と照らして調整してください。');
    }} onPointerCancel={cancel} onKeyDown={event => { if (event.key === 'Escape') cancel(); }} tabIndex={0}>
      <defs><pattern id="plan-grid" width="500" height="500" patternUnits="userSpaceOnUse"><path d="M 500 0 L 0 0 0 500" fill="none" stroke="#c7d4c3" strokeWidth="6" /></pattern></defs>
      <rect x="-700" y="-700" width={span} height={span} fill="url(#plan-grid)" />
      <rect x={preview?.x ?? 0} y={preview?.y ?? 0} width={w} height={d} fill="#e6d8b9" fillOpacity="0.7" stroke="#61765a" strokeWidth="45" />
      <text x={(preview?.x ?? 0) + w / 2} y={(preview?.y ?? 0) - 180} textAnchor="middle" fill="#52674d" fontSize="140">{w.toLocaleString()} mm</text>
      <text x={(preview?.x ?? 0) + w / 2} y={(preview?.y ?? 0) + d / 2} textAnchor="middle" fill="#66755d" fontSize="180">{(w * d / 1e6).toFixed(2)} m²</text>
      <text x={(preview?.x ?? 0) + w + 170} y={(preview?.y ?? 0) + d / 2} fill="#52674d" fontSize="130">{d.toLocaleString()} mm</text>
      {!preview && <g fill="#fffef5" stroke="#61765a" strokeWidth="20">
        <rect data-testid="resize-width" aria-label="部屋の幅をドラッグ" x={room.widthMm - 65} y={room.depthMm / 2 - 65} width="130" height="130" onPointerDown={event => start(event, 'width')} />
        <rect data-testid="resize-depth" aria-label="部屋の奥行きをドラッグ" x={room.widthMm / 2 - 65} y={room.depthMm - 65} width="130" height="130" onPointerDown={event => start(event, 'depth')} />
        <rect data-testid="resize-both" aria-label="部屋の角をドラッグ" x={room.widthMm - 80} y={room.depthMm - 80} width="160" height="160" onPointerDown={event => start(event, 'both')} />
      </g>}
    </svg><p className="plan-message" role="status">{message}</p><span className="plan-scale">グリッド 500mm · {snap ? '100mmスナップ' : 'スナップOFF'} · 単一の長方形の部屋</span>
  </div>;
}
