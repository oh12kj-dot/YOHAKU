import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import type { CatalogAsset } from '../../../packages/catalog/src/index';

export function createFurnitureModel(asset: CatalogAsset): THREE.Group {
  const group = new THREE.Group();
  const { widthMm, depthMm, heightMm } = asset.dimensions;
  const w = widthMm / 1000, d = depthMm / 1000, h = heightMm / 1000;
  const cloth = new THREE.MeshStandardMaterial({ color: asset.color, roughness: 0.96 });
  const wood = new THREE.MeshStandardMaterial({ color: '#785338', roughness: 0.65 });
  const dark = new THREE.MeshStandardMaterial({ color: '#343731', roughness: 0.55, metalness: 0.2 });
  function rounded(size: number[], pos: number[], mat: THREE.Material, radius = 0.035) {
    const mesh = new THREE.Mesh(new RoundedBoxGeometry(size[0], size[1], size[2], 3, radius), mat);
    mesh.position.set(pos[0], pos[1], pos[2]); mesh.castShadow = mesh.receiveShadow = true; group.add(mesh);
    return mesh;
  }
  function leg(x: number, z: number, height: number) { rounded([0.045, height, 0.045], [x, height / 2, z], wood, 0.008); }
  if (asset.kind === 'sofa' || asset.kind === 'chair') {
    const arm = asset.kind === 'chair' ? 0.075 : 0.13, seatHeight = h * 0.53, legHeight = 0.13;
    rounded([w - 0.04, 0.15, d - 0.03], [0, legHeight + 0.075, 0], cloth);
    rounded([w - 2 * arm, 0.16, d * 0.76], [0, seatHeight - 0.08, d * 0.1], cloth, 0.055);
    rounded([w - 2 * arm, h - seatHeight, 0.18], [0, seatHeight + (h - seatHeight) / 2, -d / 2 + 0.14], cloth, 0.055);
    for (const sign of [-1, 1]) rounded([arm, h * 0.45, d], [sign * (w / 2 - arm / 2), seatHeight * 0.82, 0], cloth);
    if (asset.kind === 'sofa') {
      const seam = new THREE.Mesh(new THREE.BoxGeometry(0.005, 0.003, d * 0.65), dark);
      seam.position.set(0, seatHeight + 0.002, d * 0.1); group.add(seam);
    }
    for (const x of [-1, 1]) for (const z of [-1, 1]) leg(x * (w / 2 - 0.1), z * (d / 2 - 0.1), legHeight);
  } else {
    const top = new THREE.Mesh(new THREE.CylinderGeometry(w / 2, w / 2, 0.055, 64), new THREE.MeshStandardMaterial({ color: asset.color, roughness: 0.65 }));
    top.position.y = h - 0.0275; top.castShadow = top.receiveShadow = true; group.add(top);
    for (const angle of [0, 2 * Math.PI / 3, 4 * Math.PI / 3]) leg(Math.cos(angle) * w * 0.3, Math.sin(angle) * d * 0.3, h - 0.055);
  }
  // Shared materials are disposed once by disposeGroup; unused materials need disposal too.
  const used = new Set<THREE.Material>();
  group.traverse(o => { if (o instanceof THREE.Mesh) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => used.add(m)); });
  [cloth, wood, dark].filter(m => !used.has(m)).forEach(m => m.dispose());
  return group;
}
export function disposeGroup(group: THREE.Object3D) {
  const geometries = new Set<THREE.BufferGeometry>(), materials = new Set<THREE.Material>(), textures = new Set<THREE.Texture>();
  group.traverse(o => {
    if (o instanceof THREE.Mesh || o instanceof THREE.Line) {
      geometries.add(o.geometry);
      (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => {
        materials.add(m);
        if (m instanceof THREE.MeshStandardMaterial && m.map) textures.add(m.map);
      });
    }
  });
  geometries.forEach(g => g.dispose()); materials.forEach(m => m.dispose()); textures.forEach(t => t.dispose()); group.clear();
}
