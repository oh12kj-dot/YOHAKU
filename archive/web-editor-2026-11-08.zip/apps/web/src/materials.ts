import * as THREE from 'three';
import { finishes, type FinishId } from '../../../packages/catalog/src/index';

export function createFinish(id: FinishId, width: number, depth: number): THREE.MeshStandardMaterial {
  const finish = finishes.find(f => f.id === id)!;
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = finish.color; ctx.fillRect(0, 0, 512, 512);
  let seed = 271;
  const random = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
  if (finish.pattern === 'wood') {
    for (let plank = 0; plank < 4; plank++) {
      ctx.fillStyle = `rgba(${random() > 0.5 ? '255,255,255' : '20,12,0'},${random() * 0.08})`; ctx.fillRect(plank * 128, 0, 128, 512);
      for (let i = 0; i < 75; i++) {
        const x = plank * 128 + random() * 126;
        ctx.strokeStyle = `rgba(55,32,10,${random() * 0.06})`; ctx.lineWidth = random() * 1.2;
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.bezierCurveTo(x - 5, 150, x + 6, 350, x, 512); ctx.stroke();
      }
      ctx.fillStyle = '#35291424'; ctx.fillRect(plank * 128, 0, 1, 512);
      ctx.fillRect(plank * 128, (plank % 2 ? 320 : 128), 128, 1);
    }
  } else if (finish.pattern === 'tile') {
    ctx.strokeStyle = '#f2f0e5'; ctx.lineWidth = 2; ctx.strokeRect(0, 0, 512, 512);
  }
  for (let i = 0; i < 10000; i++) {
    ctx.fillStyle = `rgba(30,30,20,${random() * 0.035})`; ctx.fillRect(random() * 512, random() * 512, 1, 1);
  }
  const map = new THREE.CanvasTexture(canvas); map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(width / (finish.pattern === 'wood' ? 0.72 : 0.6), depth / (finish.pattern === 'wood' ? 2.4 : 0.6));
  map.anisotropy = 4;
  return new THREE.MeshStandardMaterial({ map, roughness: finish.roughness, side: THREE.DoubleSide });
}
