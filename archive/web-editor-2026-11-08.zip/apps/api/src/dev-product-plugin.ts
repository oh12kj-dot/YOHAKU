import type { Plugin } from 'vite';
import { fetchProduct, type ProductSource } from '../../../workers/import/src/product-source.ts';

// Read-only, loopback development integration. Not a production authenticated API.
export function productSourcePlugin(): Plugin {
  const cache = new Map<string, { at: number; result: ProductSource }>();
  let lastFetch = 0;
  return { name: 'yohaku-dev-product-source', configureServer(server) {
    server.middlewares.use(async (req, res, next) => {
      const url = new URL(req.url ?? '/', 'http://127.0.0.1');
      if (url.pathname !== '/api/development/product-source') return next();
      res.setHeader('Content-Type', 'application/json; charset=utf-8'); res.setHeader('Cache-Control', 'no-store');
      const origin = req.headers.origin;
      if (req.method !== 'GET' || (origin && origin !== `http://${req.headers.host}`)) { res.statusCode = 403; res.end(JSON.stringify({ error: 'この開発画面からのみ利用できます。' })); return; }
      const input = url.searchParams.get('url') ?? '', cached = cache.get(input);
      if (cached && Date.now() - cached.at < 300000) { res.end(JSON.stringify({ data: cached.result })); return; }
      if (Date.now() - lastFetch < 5000) { res.statusCode = 429; res.end(JSON.stringify({ error: '少し待ってから再取得してください。' })); return; }
      try { lastFetch = Date.now(); const result = await fetchProduct(input); if (cache.size >= 10) cache.delete(cache.keys().next().value!); cache.set(input, { at: Date.now(), result }); res.end(JSON.stringify({ data: result })); }
      catch (error) { res.statusCode = 422; res.end(JSON.stringify({ error: error instanceof Error ? error.message : 'ページを取得できませんでした。' })); }
    });
  } };
}
